"""Adapt the pinned GPL JIANT editor without modifying the reference sources."""
from pathlib import Path
import os,re,shutil,hashlib,json,html

def build_editor(root,dist):
    site=root/'site';vendor=site/'vendor/upstream-editor';out=dist/'editor';out.mkdir(exist_ok=True)
    s=(vendor/'editor.html').read_text()
    release=json.loads((dist/'release.json').read_text()) if (dist/'release.json').exists() else {}
    def change(a,b):
        nonlocal s
        if a not in s:raise ValueError('JIANT adaptation anchor missing: '+a[:80])
        s=s.replace(a,b)
    change('<html lang="ja">','<html lang="en">')
    s=re.sub(r'<link[^>]+(?:fonts.googleapis|fonts.gstatic)[^>]*>','',s)
    s=re.sub(r'<p class="kofi".*?</p>','',s,flags=re.S)
    s=s.replace('JIANT FM by Juan Jiant. GPL-3.0.','JAZZY editor · Adapted from JIANT by Juan Jiant and Felucca by Leo Kuroshita. GPL-3.0.')
    s=s.replace('JIANT installer','JAZZY installation').replace('The sound changed on the device: read again','Data refreshed')
    s=s.replace('[EXPECT.gcount, 32, 36, 37, 66, 67, 69, 71]','[78]').replace('[[120, 112], [99, 91], [91, 83], [89, 81], [69, 61], [57, 49]]','[[127, 119]]')
    s=re.sub(r'<h1 class="jiant-wordmark">.*?</h1>','',s)
    s=re.sub(r'<title>.*?</title>','<title>JAZZY — Web Editor</title>',s)
    change('let lang = (navigator.language || "en").toLowerCase().startsWith("ja") ? "ja" : "en";','let lang = "en";')
    change('const MOCK = QS.get("mock") === "1";','const MOCK = false;\nconst WORKSPACE = QS.get("target") !== "usb";\nlet workspace = null;')
    s=s.replace('if (!MOCK && !navigator.requestMIDIAccess)','if (!WORKSPACE && !navigator.requestMIDIAccess)')
    change('if (MOCK) { mock = makeMockDevice({ legacy: QS.get("legacy") === "1" }); access = mock.access; }','if (WORKSPACE) { const w = await import("./workspace.mjs"); workspace = await w.createWorkspace(m => {$("workspace-status").textContent=m;}); access = workspace.access; }')
    change('if (!/^(?:JIANT|FELUCCA)\\b/i.test(info.version || "")) throw new Error("Not a JIANT editor device");', 'if (info.version !== "JAZZY v0.1b1" || info.nengines !== 43 || info.ntrk !== 6 || info.pcount !== 127 || info.gcount !== 78 || info.pe0 !== 119 || info.catalogPage !== 32) throw new Error("This editor requires the matching JAZZY firmware");')
    change('function replyMatches(cmd, args, a) {','function replyMatches(cmd, args, a) { if(cmd===80)return args.length?a[0]===args[0]&&a[1]===args[1]:a.length===6&&String.fromCharCode(...a.slice(0,5))===\"SIX3\\0\";')
    change('function engineOrder(names) {','function engineOrder(names) { return [17,2,3,18,19,20,0,12,7,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,16,15,38,39,40,41,21,42].filter(i => names[i] && names[i] !== "-"); }\nfunction upstreamEngineOrder(names) {')
    change('["LFO", 0, [9, 10, 11, 12]]','["LFO 1", 0, [9, 10, 11, 12]], ["LFO 2", 0, [pe0-4,pe0-3,pe0-2,pe0-1]]')
    change('["LFO 2", 0, [pe0-4,pe0-3,pe0-2,pe0-1]]','["LFO 2", 0, [pe0-4,pe0-3,pe0-2,pe0-1]], ["LFO 2 DEST", 2, [0,1,2,3]]')
    change('function paramRow(s, id) {','function paramRow(s, id) { if(s===2)return lfo2DestRow(id);')
    change('o.lyric = ty >= 0','o.lfo2Dest = ty >= 6 && trailer[ty-6]===0x32 && trailer[ty-5]===1 && trailer[ty-4]===1;\n    o.catalogPage = ty >= 3 && trailer[ty-3]===0x5a && trailer[ty-2]===1 ? trailer[ty-1] : 0;\n    o.lyric = ty >= 0')
    change('function enumShown(d) {','function enumShown(d) { if(d.names?.[1]==="LFO 1"&&d.names?.[15]==="LFO 2")return [0,1,15,2,3,4,5,6,7,8,9,10,11,12,13,14];')
    s=s.replace('["LFO DEST", 0,','["LFO 1 DEST", 0,')
    s=s.replace('["CHORUS", 1,','["PHASER", 1,')
    # Actual command tokens, rather than MIDI pitch names, for the singleton Break track.
    change('const stepNotes = (s) => s.notes.slice(0, s.n).map(noteName).join(" ");','const breakLabel = n => n<16?`C${n+1}`:n<32?`R${n-15}`:n===32?"A":n===33?"B":n===34?"RET":String(n);\nconst isBreak = () => !!dev && dev.dump?.engine===15;\nconst breakParse = text => { const words=String(text).trim().toUpperCase().split(/[ ,]+/).filter(Boolean); if(words.length>4)return null; const ns=words.map(w=>/^C([1-9]|1[0-6])$/.test(w)?+w.slice(1)-1:/^R([1-9]|1[0-6])$/.test(w)?+w.slice(1)+15:w==="A"?32:w==="B"?33:w==="RET"?34:/^([0-9]|[12][0-9]|3[0-4])$/.test(w)?+w:NaN); return ns.some(Number.isNaN)?null:ns; };\nconst stepNotes = s => s.notes.slice(0,s.n).map(isBreak()?breakLabel:noteName).join(" ");')
    change('const notes = parseNotes(c.notes.value), hits = parseHits(c.hits.value);','const notes = isBreak()?breakParse(c.notes.value):parseNotes(c.notes.value), hits = parseHits(c.hits.value);')
    change('c.notes.value = stepNotes(s);','c.notes.value = stepNotes(s); c.notes.setAttribute("aria-label",`${isBreak()?"Break command":"Notes"} ${+tr.dataset.i+1}`); c.notes.placeholder=isBreak()?"C1 / R1 / A / B / RET":"—";')
    change('for (let i = 0; i < 8 && pe0 + i < d.info.pcount; i++) d.pdesc[pe0 + i] = await getDescOrNull(0, pe0 + i, d);','for (const id of [83,84,85,86,87,88,89,90,...Array.from({length:8},(_,i)=>pe0+i)]) d.pdesc[id] = await getDescOrNull(0,id,d);')
    change('const send = () => writeStep(i, tr);','let noteTimer; const send = () => {clearTimeout(noteTimer);writeStep(i,tr);}; notes.addEventListener("input",()=>{clearTimeout(noteTimer);noteTimer=setTimeout(send,180);});')
    change('dev.steps[i] = parse[CMD.STEP_SET](await rq(req.stepSet(i, s)));','dev.steps[i] = parse[CMD.STEP_SET](await rq(req.stepSet(i, s))); renderGrid(); tr.dataset.committed=stepNotes(dev.steps[i]);')
    s=s.replace('$("noteshelp").textContent = t("notesHelp");','$("noteshelp").textContent = isBreak()?"C1–C16 chops · R1–R16 repeats/up-down · A / B samples · RET return. NOTE / TIE / REST control playback; up to four commands per step.":t("notesHelp");')
    change('await restoreBackup((r, o) => sessionRequest(d, r, o), archive, backupProgress);','await restoreBackup((r,o)=>{if(r[0]===CMD.BACKUP_PUT&&r[1][0]===2)selfLoad();return sessionRequest(d,r,o);},archive,backupProgress);')
    # Current data ABI has four projects; old JIANT archives must not be silently truncated.
    s=s.replace('JIANT-backup','JAZZY-backup')
    s=s.replace('/felucca|jiant|skiff|fm[ _-]*1|','/jazzy|felucca|jiant|skiff|fm[ _-]*1|')
    s=s.replace('backupDone: "Backup saved"','backupDone: "Backup ready — use DOWNLOAD above"')
    s=s.replace('backupTitle: "Complete backup"','backupTitle: "Musical archive"').replace('backupHelp: "Save the current music, A–D, sound banks and settings to this computer."','backupHelp: "Save all four projects, A–D sections, sounds and settings. Break sample audio is separate; use PLAY’s .fm1save for sample-inclusive backups."')
    s=s.replace('return lib.filter((p) => (!q', 'return lib.filter((p) => (p.engineName!=="BREAK" || dev?.dump?.engine===15) && (!q')
    s=s.replace('const rows = devicePresetRows(d.info, d.names, p);','const rows = devicePresetRows(d.info, d.names, p).filter(r=>r.engine!==15 || d.dump?.engine===15);')
    s=s.replace('projects: "Projects"','projects: "Sections A–D"')
    # Adaptations inside the original UI closure can use its real protocol/state functions.
    change('applyLang();\nshowTab(tab);\nlibInit();','applyLang();\nshowTab(tab);\nlibInit();\n'+(site/'editor/adapter.js').read_text())
    change('const TABS = ["sound", "fm6", "sequencer", "tracks", "library", "projects", "settings"];','const TABS = ["sound", "fm6", "sequencer", "tracks", "library", "projects", "samples", "settings"];')
    s=s.replace('<button role="tab" data-tab="settings"','<button role="tab" data-tab="samples">SAMPLES</button><button role="tab" data-tab="settings"',1)
    s=s.replace('<section class="panel" id="p-settings"','<section class="panel" id="p-samples" data-tab="samples" hidden></section><section class="panel" id="p-settings"',1)
    s=s.replace('</head>','<link rel="stylesheet" href="rhythmer.css"></head>')
    s=s.replace('<main>','<main><section id="rhythmer-mode"><a href="../#editor" target="_top" class="rhy-title">JAZZY / EDITOR</a><div class="bar"><a id="mode-browser" href="?target=browser">BROWSER WORKSPACE</a><a id="mode-usb" href="?target=usb">USB FM-1</a><a href="../emulator/">WEB PLAY ↗</a></div><p id="workspace-status" role="status"></p><p id="mode-note"></p></section>',1)
    codec=Path(os.environ.get("RHYTHMER_BUILD_DIR",root/"rhythmer/build-ssd"))/"workspace.wasm"
    editor_version=hashlib.sha256(b''.join(p.read_bytes() for p in sorted((site/'editor').iterdir()) if p.is_file())+(codec.read_bytes() if codec.exists() else b'')).hexdigest()[:12]
    for entry in ['workspace.mjs','break-samples.mjs','fm1backup.js']:
        s=s.replace('./'+entry,'./'+entry+'?v='+editor_version)
    s=s.replace('href="rhythmer.css"','href="rhythmer.css?v='+editor_version+'"')
    version=html.escape(' · '.join(str(release[k]) for k in ('version','buildRevision') if k in release) or 'development')
    s=s.replace('class="rhy-title">JAZZY / EDITOR</a>',f'class="rhy-title">JAZZY / EDITOR</a><span class="rhy-build">{version}</span>')
    # Keep old editor files and older connected firmware readable under the current label.
    change('const parse = {', 'const engineNameV2 = name => name === "SERUM" || name === "WAVETABL" ? "WAVETABLE" : name === "KW ANALO" ? "KW ANALOG" : name;\n\nconst parse = {')
    change('o.engines.push(r.s())','o.engines.push(engineNameV2(r.s()))')
    change('engineName: String(pt.engineName ?? "")','engineName: engineNameV2(String(pt.engineName ?? ""))')
    change('const nm = name || (fileEngines || [])[idx];','const nm = engineNameV2(name || (fileEngines || [])[idx]);')
    change('obj.presetName || obj.engineName || "PATCH"','obj.presetName || engineNameV2(obj.engineName) || "PATCH"')
    change('lib = ((await store.all()) || []).filter((p) => p && p.id);','lib = ((await store.all()) || []).filter((p) => p && p.id).map(p => ({ ...p, engineName: engineNameV2(p.engineName) }));')
    change('libMeta = (await store.getMeta("layout")) || libMeta;','libMeta = (await store.getMeta("layout")) || libMeta;\n      if (Array.isArray(libMeta.engines)) libMeta.engines = libMeta.engines.map(engineNameV2);')
    change('Array.isArray(obj.engines) ? obj.engines : null','Array.isArray(obj.engines) ? obj.engines.map(engineNameV2) : null')
    # Match the JAZZY protocol's 14-bit factory preset IDs on all editor paths.
    change('preset: (e, p) => [CMD.PRESET, [e & 0x7F, p & 0x7F]],',
           'preset: (e, p) => [CMD.PRESET, [e & 0x7f, p & 0x7f, (p >> 7) & 0x7f]],')
    change('names: (e) => [CMD.NAMES, [e & 0x7F]],',
           'names: (e, start, count) => [CMD.NAMES, [e & 0x7f, start & 0x7f, (start >> 7) & 0x7f, count]],')
    change('case CMD.STEP_GET: case CMD.STEP_SET: case CMD.NAMES: return a[0] === args[0];',
           'case CMD.STEP_GET: case CMD.STEP_SET: return a[0] === args[0];\n    case CMD.NAMES: return a[0] === args[0] && a.at(-4) === args[1] && a.at(-3) === args[2];')
    change('try { o.titles.push(r.s(), r.s()); } catch (e) { o.titles = []; }   /* older firmware: no page titles */',
           'o.titles.push(r.s(), r.s());\n    o.start = r.b() | r.b() << 7;\n    o.total = r.b() | r.b() << 7;')
    change('for (let i = 0; i < info.gcount; i++) o.g.push(r.v());\n    return o;',
           'for (let i = 0; i < info.gcount; i++) o.g.push(r.v());\n    o.preset |= r.b() << 7;\n    return o;')
    change('return { engine: r.b(), preset: r.b() }; },',
           'return { engine: r.b(), preset: r.b() | r.b() << 7 }; },')
    change('return { engine: r.b(), preset: r.b(), track: r.i < a.length ? r.b() : 0 };',
           'const engine = r.b(), low = r.b(), track = r.b(); return { engine, preset: low | r.b() << 7, track };')
    change('mute: r.b(), armed: r.b() });\n    return o;',
           'mute: r.b(), armed: r.b() });\n    for (const track of o.tracks) track.preset |= r.b() << 7;\n    return o;')
    change('for (let i = 0; i < info.pcount; i++) o.p.push(r.v());\n    return o;',
           'for (let i = 0; i < info.pcount; i++) o.p.push(r.v());\n    o.preset |= r.b() << 7;\n    return o;')
    change("""    d.titles = [];
    for (let e = 0; e < d.info.nengines; e++) {
      const r = parse[CMD.NAMES](await sessionRequest(d, req.names(e)));
      d.names[e] = r.names;
      d.titles[e] = r.titles;
    }""", """    if (!d.titles) {
      const names = [], titles = [];
      for (const engine of engineOrder(d.info.engines)) {
        names[engine] = [];
        let total;
        do {
          const start = names[engine].length;
          const page = parse[CMD.NAMES](await sessionRequest(d, req.names(engine, start, d.info.catalogPage)));
          if (page.start !== start || page.total < start || page.total > 2048 ||
              page.names.length !== Math.min(d.info.catalogPage, page.total - start) ||
              (total !== undefined && page.total !== total)) throw Error("Invalid JAZZY catalog page");
          total = page.total;
          titles[engine] = page.titles;
          names[engine].push(...page.names);
        } while (names[engine].length < total);
      }
      d.names = names;
      d.titles = titles;
    }""")
    # LXR stores its selected voice as page + voice in the track parameters.
    change('tr.tracks[i].pan = ids.pan == null ? null : d.p[ids.pan];',
           """tr.tracks[i].pan = ids.pan == null ? null : d.p[ids.pan];
      if (d.engine === 42 && tr.tracks[i].engine === d.engine) {
        const page = d.p[83] >= 0 && d.p[83] < 5 ? d.p[83] : 0;
        tr.tracks[i].preset = Math.min(594, page * 126 + Math.max(0, Math.min(125, d.p[info.pe0])));
      }""")
    change('hidden: aliasOf(names, i) !== i', 'hidden: e !== 42 && aliasOf(names, i) !== i')
    change('aliasOf(names[engine], row.preset) === row.preset', 'engine === 42 || aliasOf(names[engine], row.preset) === row.preset')
    change('</footer>', ' · <a href="../downloads/JAZZY-web-editor-source-20261110.3.tar.gz">Editor source (GPL-3.0) ↓</a></footer>')
    change('const TAB_KEY = "felucca-editor-tab";','const TAB_KEY = "jazzy-editor-tab";')
    change('indexedDB.open("felucca-editor", 1)','indexedDB.open("jazzy-editor", 1)')
    change('["MASTER", 1, [21, 25, 26, 13]]',
           '["MASTER", 1, [21, 25]], ["DUCK ENV", 1, [26, 75, 13]], ["DUCK INPUT", 1, [71, 73, 76, 74, 77]]')
    (out/'index.html').write_text(s)
    b=(vendor/'fm1backup.js').read_text().replace('length: 32','length: 16')
    # Do not accept foreign ABI backups or allow unknown objects to be skipped during restore.
    b=b.replace('if (!file || file.format !== "felucca-backup" || file.version !== 1 || !ids)','if (!file || file.format !== "felucca-backup" || file.version !== 1 || !ids || ids.length !== 27 || file.firmware !== "JAZZY v0.1b1")')
    b=b.replace('if (a[2] === 1) { done += o.size; onProgress(done, total); continue; }','if (a[2] === 1) throw new Error("JAZZY archive object rejected; restore stopped");')
    (out/'fm1backup.js').write_text(b)
    for name in ['fukiai.ttf','FUKIAI-LICENSE.txt','LICENSE.txt','UPSTREAM.json']:
        shutil.copy2(vendor/name,out/name)
    for f in (site/'editor').iterdir():
        if f.is_file():shutil.copy2(f,out/f.name)

    for p in out.glob('*.mjs'):
        text=p.read_text()
        text=re.sub(r"(from\s+['\"])(\./[^'\"]+\.(?:mjs|js))(['\"])",lambda m:m[1]+m[2]+'?v='+editor_version+m[3],text)
        text=text.replace("'./break-convert-worker.mjs'","'./break-convert-worker.mjs?v="+editor_version+"'")
        p.write_text(text)

    codec=Path(os.environ.get("RHYTHMER_BUILD_DIR",root/"rhythmer/build-ssd"))/"workspace.wasm"
    if codec.exists():shutil.copy2(codec,out/"workspace.wasm")
