"""Extract only the editor's factory banks from the exact JAZZY update."""
import base64
import hashlib
import json
from pathlib import Path
import struct
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'rhythmer/tools'))
from fm1pkg_make import enc

def seed(package, release, out):
    data = package.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    assert digest == json.loads(release.read_text())['sha256']
    logical = b''.join(data[i * 48:i * 48 + 47] for i in range(20)) + data[960:]
    entry = bytearray(logical[64:144])
    enc(entry, 0, len(entry))
    assert entry[64:73] == b'flash.bin'
    offset, size = struct.unpack_from('<II', entry, 8)
    flash = logical[offset:offset + size]
    assert all(flash[base:base+7] == b'FSMP\x0c\0\1' for base in (0xA0000, 0xB4000))
    sectors = []
    for at in range(0x93000, len(flash) - 4095, 4096):
        chunk = flash[at:at + 4096]
        if chunk != b'\xff' * 4096:
            sectors.append(dict(at=at, data=base64.b64encode(chunk).decode()))
    out.write_text(json.dumps(dict(format='fm1-emulator-save', version=1, hash=digest, sectors=sectors), separators=(',', ':')))

if __name__ == '__main__':
    seed(*(Path(arg) for arg in sys.argv[1:]))
