# JAZZY Web Editor source

The browser editor uses JAZZY's real project and preset code compiled to WASM.
The UI is adapted from the pinned GPL JIANT editor in `site/vendor/upstream-editor`.
The original licenses and source notices are included there and at the repository root.

From the source root, use the matching JAZZY firmware build and WASI SDK 27.
Set `RHYTHMER_BUILD_DIR` to a build directory containing the matching generated
`gen/` headers and set `WASI_CLANG` to the SDK's clang. Build and prepare the site:

```sh
sh tools/six/build_editor_workspace.sh
PYTHONPATH=tools/six python3 -c 'from pathlib import Path; from site_editor import build_editor; build_editor(Path.cwd(), Path("www"))'
python3 tools/six/editor_seed.py /path/to/matching/felucca.fwsc www/release.json www/editor/factory-seed.json
```

The deployed site's release manifest and factory seed must identify the same
firmware hash. Serve the output over HTTPS or localhost for Web Locks and Web MIDI.
