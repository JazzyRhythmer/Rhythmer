#define UI_TEST_NO_MAIN 1
#include "jazzy_host.h"

static int check_preset(const char *name, unsigned pitch, int32_t step_limit)
{
    const engine_t *engine = ENGINES[ENGI_JUNO];
    unsigned preset = 0;
    while (preset < engine->npresets && !str_eq(factory_preset(engine, preset)->name, name))
        preset++;
    if (preset == engine->npresets) {
        printf("Missing FM-106 preset: %s\n", name);
        return 1;
    }
    track_t *t = &trk[0];
    set_engine_of(t, ENGI_JUNO);
    apply_preset_to(t, preset);
    t->engine = t->eng_req;
    t->xf = t->xf_on = t->xin = 0;
    t->mono_note = t->nmono = 0;
    t->p[P_VOICE] = V_POLY;
    memset(t->v, 0, sizeof t->v);
    trk_note_on(t, pitch, 108);
    voice_t *v = voice_alloc(t, pitch);
    int32_t previous = 0, max_step = 0, peak = 0;
    unsigned release = FS / CTL;
    for (unsigned block = 0; block < release + FS / (4 * CTL); block++) {
        if (block == release)
            trk_note_off(t, pitch);
        int32_t out[CTL];
        track_render(t, out, CTL);
        for (unsigned i = 0; i < CTL; i++) {
            int32_t delta = abs(out[i] - previous);
            if (delta > max_step) max_step = delta;
            if (abs(out[i]) > peak) peak = abs(out[i]);
            previous = out[i];
        }
        if (block == FS / (16 * CTL)) {
            jazzy_voice_t *state = jazzy_state(t, v);
            uint32_t phase = state->juno.osc.ph;
            float filter = state->juno.f.z[3];
            unsigned age = v->age;
            trk_note_on(t, pitch, 108);
            if (v->age == age || !v->env_out || state->juno.osc.ph != phase || state->juno.f.z[3] != filter) {
                printf("%s: active retrigger reset oscillator/filter state\n", name);
                return 1;
            }
        }
    }
    printf("%s MIDI %u: peak=%d max step=%d (limit %d)\n", name, pitch, peak, max_step, step_limit);
    return peak < 1000 || max_step > step_limit;
}

static int check_retrigger(unsigned engine, unsigned preset)
{
    track_t *t = &trk[0];
    set_engine_of(t, engine);
    apply_preset_to(t, preset);
    t->engine = t->eng_req;
    t->xf = t->xf_on = t->xin = 0;
    t->mono_note = t->nmono = 0;
    memset(t->v, 0, sizeof t->v);
    trk_note_on(t, 36, 108);
    int32_t out[CTL];
    for (unsigned block = 0; block < 31; block++)
        track_render(t, out, CTL);
    int32_t last = out[CTL - 1];
    trk_note_off(t, 36);
    trk_note_on(t, 36, 108);
    track_render(t, out, CTL);
    printf("%s repeated note: sample step=%d\n", factory_preset(ENGINES[engine], preset)->name, out[0] - last);
    return out[0] != last;
}

static int check_chord_change(void)
{
    track_t *t = &trk[0];
    set_engine_of(t, ENGI_KW_WAVE);
    apply_preset_to(t, 0); /* Night Bus */
    t->engine = t->eng_req;
    t->xf = t->xf_on = t->xin = 0;
    t->p[P_VOICE] = V_POLY;
    memset(t->v, 0, sizeof t->v);
    trk_note_on(t, 36, 127);
    trk_note_on(t, 43, 127);
    trk_note_on(t, 48, 127);
    trk_note_on(t, 52, 127);
    int32_t out[CTL];
    for (unsigned block = 0; block < 402; block++)
        track_render(t, out, CTL);
    int32_t previous = out[CTL - 1], max_step = 0;
    trk_note_on(t, 35, 127);
    trk_note_on(t, 42, 127);
    trk_note_on(t, 47, 127);
    trk_note_on(t, 50, 127);
    track_render(t, out, CTL);
    for (unsigned i = 0; i < CTL; i++) {
        int32_t step = abs(out[i] - previous);
        if (step > max_step) max_step = step;
        previous = out[i];
    }
    printf("Night Bus chord change: max sample step=%d\n", max_step);
    return max_step > 4000;
}

static int check_cold_chord(unsigned engine, unsigned preset)
{
    track_t *t = &trk[0];
    memset(t->v, 0, sizeof t->v);
    set_engine_of(t, engine);
    apply_preset_to(t, preset);
    t->engine = t->eng_req;
    t->xf = t->xf_on = t->xin = 0;
    t->p[P_VOICE] = V_POLY;
    int32_t out[CTL], max_step = 0;
    track_render(t, out, CTL);
    static const uint8_t notes[] = {36, 43, 48, 52};
    for (unsigned i = 0; i < sizeof notes; i++)
        trk_note_on(t, notes[i], 127);
    track_render(t, out, CTL);
    for (unsigned i = 1; i < 8; i++) {
        int32_t step = abs(out[i] - out[i - 1]);
        if (step > max_step) max_step = step;
    }
    printf("%s cold chord: max early sample step=%d\n", factory_preset(ENGINES[engine], preset)->name, max_step);
    return out[0] != 0 || max_step == 0 || max_step > 1800;
}

int main(void)
{
    ui_power_on();
    fm6_init();
    power_on_parts();
    six_native_init();
    song.playing = 0;
    int bad = check_preset("A48 Synth Bass", 36, 10000);
    bad |= check_preset("A72 Pluck Sweep", 60, 14000);
    bad |= check_preset("B25 Organ Bell", 36, 10000);
    bad |= check_retrigger(ENGI_PHASE, 14);
    bad |= check_retrigger(ENGI_M2SID, 2);
    bad |= check_retrigger(ENGI_S1, 0);
    bad |= check_retrigger(ENGI_ACID, 1);
    bad |= check_chord_change();
    bad |= check_cold_chord(ENGI_PHASE, 1);  /* Organ */
    bad |= check_cold_chord(ENGI_ANALOG, 23); /* Glass Keys */
    return bad;
}
