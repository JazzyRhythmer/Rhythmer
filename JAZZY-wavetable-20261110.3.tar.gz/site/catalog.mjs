// Engine IDs match the firmware; display order is grouped by family.
const number = new Intl.NumberFormat('en');

export const engines = [
  [0, "ANALOG", "synth", 25, "Classic oscillator shapes, detune and resonant filtering. The sports car surges right on accents while lane markings rush past."],
  [23, "FMINI-1", "synth", 200, "Three-oscillator analog voicing for heavy basses and leads."],
  [40, "S1VAVE", "synth", 64, "SH-101-style oscillator, sub and noise with a fast filter envelope."],
  [16, "ACID 303", "synth", 4, "Saw or square through a resonant ladder, with accent and slide."],
  [39, "PROPHET", "synth", 24, "Poly analog, oscillator sync and poly-mod motion."],
  [25, "FM-106", "synth", 24, "Juno-inspired DCO voicing, sub layer and soft pads."],
  [26, "CS-1", "synth", 12, "Detuned analog voices with a wide, bright spectrum."],
  [24, "OBERVAVE", "synth", 12, "Oberheim-inspired analog colors with resonant filter movement."],
  [41, "HYDRA", "synth", 15, "A curated digital engine with wavetable and mutation-inspired textures."],
  [38, "MELO CZ", "synth", 24, "Melodee's CZ-style phase distortion with DCW shaping."],
  [12, "FM6", "synth", 15, "Six-operator FM with editable operators, ratios and envelopes."],
  [18, "FM+STAT", "synth", 5, "Compact FM with moving ratios and a sharp, inharmonic edge."],
  [2, "PHASE", "synth", 16, "Phase-distorted shapes for rounded keys and metallic peaks."],
  [17, "WAVETABLE", "synth", 8, "Wavetable-style morphing and harmonic warp."],
  [3, "LOFI", "synth", 17, "Stepped waveforms and Byte and Float modes for digital grit."],
  [19, "SWAV-SAW", "synth", 6, "Stacked sawtooth voices for wide leads and textures."],
  [20, "SID-6581", "synth", 6, "Chip-style pulse and waveform colors with characteristic grit."],
  [7, "WHEEL", "synth", 10, "Tonewheel-style organ harmonics and rotor movement."],
  [22, "TRIO", "synth", 5, "Melodee's three-oscillator colors, from stacks to unison."],
  [27, "KW ANALOG", "synth", 12, "K-WASUB analog oscillator shapes with fold."],
  [28, "KW CS", "synth", 12, "K-WASUB CS-style animated analog tones."],
  [29, "KW WAVE", "synth", 9, "Eight curated K-WASUB wave frames with scan and warp."],
  [30, "KW FM", "synth", 12, "K-WASUB frequency modulation with direct index control."],
  [31, "KW PHASE", "synth", 1, "Focused K-WASUB phase shaping."],
  [32, "KW SYNC", "synth", 1, "Hard-sync sweeps and sharp oscillator contours. Two clock hands start together on each note, then drift at different speeds."],
  [34, "KW GROWL", "synth", 11, "Rough, moving timbres for basses and texture."],
  [35, "KW ADD", "synth", 9, "Additive harmonic layers with spectrum tilt."],
  [37, "HORTATOR", "drum", 57, "Hortator drum synthesis. Pick one sound for the track and shape each hit."],
  [42, "LXR", "drum", 595, "LXR-02 drum synthesis. 85 factory sets projected into individual voices."],
  [33, "KW KICK", "drum", 7, "Dedicated K-WASUB kick synthesis with punch and pitch shaping. A carnival hammer sends a puck up the strength meter on each hit."],
  [15, "BREAK", "sample", 2, "Amen and Think in two slots, with slicing, rolls and A/B switching."]
].map(([id, name, kind, presets, details]) => {
  const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
  const asset = 'assets/engine-' + String(id).padStart(2, '0');
  const revision = id === 19 ? '?v=rider-speed' : id === 37 ? '?v=hortator' : [0, 32, 33].includes(id) ? '?v=scene-2' : '';
  const unit = kind === 'sample' ? 'loops' : presets === 1 ? 'sound' : 'sounds';
  const soundCount = number.format(presets) + ' ' + unit;
  return {
    id, name, kind, details, slug, soundCount,
    href: 'engine.html?model=' + slug,
    still: asset + '.png' + revision,
    motion: asset + '.webp' + revision,
  };
});
