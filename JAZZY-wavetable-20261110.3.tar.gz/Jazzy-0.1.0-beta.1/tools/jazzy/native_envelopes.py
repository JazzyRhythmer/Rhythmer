"""Translate imported envelope response into JAZZY's shared ADSR time scale."""

import math
import re
from functools import lru_cache


@lru_cache(maxsize=None)
def table(path, name):
    body = re.search(rf"\b{name}\[128\]\s*=\s*\{{([^}}]+)\}}", path.read_text())[1]
    return [int(x.strip(), 0) for x in body.strip().rstrip(",").split(",")]


def time_knob(ms):
    return max(0, min(127, round(127 * math.log(max(ms, 1), 10000))))


def residual_ms(coef, tick_ms, residual=0.01):
    return tick_ms * math.log(residual) / math.log(coef) if coef else tick_ms


def roland_env(env, inc, mul, tick_ms):
    a, d, s, r = env
    return [time_knob(math.ceil(16383 / inc[a]) * tick_ms),
            time_knob(residual_ms(mul[d] / 65536, tick_ms)), s,
            time_knob(residual_ms(mul[r] / 65536, tick_ms))]


def s1vave(row, upstream, amp_gate):
    if amp_gate:
        # The source VCA follows key gate independently of its filter EG.
        return [time_knob(3), 0, 127, time_knob(8)]
    a, d, s, r = row
    d, r = min(127, d * 115 // 106), min(127, r * 5 // 4)
    p = upstream / "s1vave/firmware/gen/obv_tables.h"
    att = table(p, "ENV_K_ATT")[a]
    dec = table(p, "ENV_K_DEC")[d]
    rel = table(p, "ENV_K_REL")[r]
    ms = 16000 / 44100
    # The analog-style attack aims above full level and stops at 1.
    return [time_knob(residual_ms(1 - att / 2**24, ms, 3 / 11)),
            time_knob(residual_ms(1 - dec / 2**24, ms)),
            s + ((s * (127 - s) * 29) >> 12),
            time_knob(residual_ms(1 - rel / 2**24, ms))]


def fm106(raw, upstream):
    if raw[35]:
        return [time_knob(4.2335), 0, 127, time_knob(8)]
    p = upstream / "fm106/firmware/src/fm106_tables.h"
    return roland_env(raw[16:20], table(p, "FM106_ENV_ATK"),
                      table(p, "FM106_ENV_DEC_REL"), 4.2335)


def obervave(env, upstream):
    a, d, s, r = env
    p = upstream / "obervave/firmware/gen/obv_tables.h"
    att = table(p, "ENV_K_ATT")[a]
    dr = table(p, "ENV_K_DEC")
    ms = 16000 / 44100
    return [time_knob(residual_ms(1 - att / 2**24, ms, 3 / 11)),
            time_knob(residual_ms(1 - dr[d] / 2**24, ms)), s,
            time_knob(residual_ms(1 - dr[r] / 2**24, ms))]


def cs1(env, upstream):
    a, d, s, r = env
    p = upstream / "cs1/firmware/gen/cs1_tables.h"
    att = table(p, "ATT_Q16")[a]
    dr = table(p, "DEC_Q16")
    ms = 32000 / 44100
    return [time_knob(math.ceil(65536 / att) * ms),
            time_knob(residual_ms(1 - dr[d] / 65536, ms)), s,
            time_knob(residual_ms(1 - dr[r] / 65536, ms))]
