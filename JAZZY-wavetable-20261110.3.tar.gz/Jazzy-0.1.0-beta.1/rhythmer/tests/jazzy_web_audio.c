/* SPDX-License-Identifier: GPL-3.0-only */
/* Offline website auditions using the JAZZY mixer, factory voices and native FX. */
#define UI_TEST_NO_MAIN 1
#include "jazzy_host.h"

typedef struct {
    unsigned start, length, velocity;
    uint8_t notes[4];
} phrase_note_t;

static const phrase_note_t bass[] = {
    {0, 2, 112, {36}}, {3, 1, 91, {36}}, {6, 1, 105, {43}}, {8, 2, 108, {34}},
    {11, 1, 95, {46}}, {13, 1, 103, {43}}, {15, 1, 89, {35}}, {16, 3, 114, {36}},
    {20, 1, 104, {48}}, {22, 1, 98, {43}}, {24, 2, 110, {39}}, {27, 1, 93, {41}},
    {29, 1, 101, {43}}, {31, 1, 92, {35}},
};
static const phrase_note_t pad[] = {
    {0, 8, 101, {48, 55, 60, 63}}, {8, 8, 100, {44, 55, 60, 67}},
    {16, 8, 104, {51, 58, 62, 67}}, {24, 8, 97, {46, 53, 60, 65}},
};

/* Sustained Cmaj7 – Am7 – Fmaj7 – G9sus4 with a full room tail. */
static const phrase_note_t ober_pad[] = {
    { 0, 15,  98, {48, 55, 59, 64}},
    {16, 15,  94, {45, 52, 55, 60}},
    {32, 15,  98, {53, 57, 60, 64}},
    {48, 15,  96, {43, 53, 57, 60}},
};

typedef struct {
    const char *slug;
    unsigned engine, program, bpm, level, delay, reverb, phaser;
    const phrase_note_t *phrase;
    unsigned notes;
} audition_t;

static const audition_t auditions[] = {
    {"fmini", ENGI_FMINI, 137, 116, 104, 0, 0, 0, bass, NELEM(bass)},
    {"ober", ENGI_OBER, 7, 104, 88, 0, 53, 0, ober_pad, NELEM(ober_pad)},
    {"hydra", ENGI_HYDRA, 3, 100, 83, 26, 37, 15, pad, NELEM(pad)},
    {"lxr", ENGI_LXR, 78, 124, 0, 0, 0, 0, NULL, 0},
};

static void track_sound(unsigned i, unsigned engine, unsigned patch, int level, int pan, int reverb)
{
    track_t *t = &trk[i];
    set_engine_of(t, engine);
    apply_preset_to(t, patch);
    t->engine = t->eng_req;
    t->p[P_LEVEL] = level;
    t->p[P_PAN] = pan;
    t->p[P_MUTE] = 0;
    t->p[P_AMODE] = 0;
    t->p[P_DIST] = 0;
    t->p[P_CHOR] = 0;
    t->p[P_DLY] = 0;
    t->p[P_REV] = reverb;
}

static void phrase_step(const audition_t *a, unsigned step)
{
    for (unsigned i = 0; i < a->notes; i++) {
        const phrase_note_t *n = &a->phrase[i];
        if (step != n->start + n->length) continue;
        for (unsigned j = 0; j < 4 && n->notes[j]; j++)
            trk_note_off(&trk[0], n->notes[j]);
    }
    for (unsigned i = 0; i < a->notes; i++) {
        const phrase_note_t *n = &a->phrase[i];
        if (step != n->start) continue;
        for (unsigned j = 0; j < 4 && n->notes[j]; j++)
            trk_note_on(&trk[0], n->notes[j], n->velocity - j * 4u);
    }
}

static int render_lxr(const audition_t *a, FILE *out)
{
    const unsigned steps = 16;
    /* Unchanged straight house pattern and LECTRO snare and hats.
     * BROKE D3 is a factory sine kick with a smooth onset and short tail. */
    static const uint8_t slots[] = {0, 3, 5, 6};
    static const uint8_t levels[] = {86, 96, 84, 66};
    static const uint8_t velocities[] = {112, 108, 78, 88};
    static const uint16_t house[] = {0x1111, 0x1010, 0x2222, 0x4444};
    for (unsigned i = 0; i < NTRK; i++) {
        trk[i].p[P_MUTE] = 1;
        for (unsigned j = 0; j < NSTEP; j++) gclear(&trk[i].step[j]);
    }
    for (unsigned i = 0; i < NELEM(slots); i++) {
        unsigned preset = i ? a->program * 7u + slots[i] : 14u * 7u + 2u;
        track_sound(i, a->engine, preset, levels[i], 0, 0);
        track_t *t = &trk[i];
        t->p[P_SLEN] = steps;
        t->p[P_SDIV] = 2;  /* 1/16 */
        t->p[P_SSWING] = 0;
        for (unsigned j = 0; j < steps; j++) {
            if (!(house[i] & (1u << j))) continue;
            step_t *s = &t->step[j];
            s->time = ST_NOTE;
            s->n = 1;
            s->note[0] = 60; /* native pitch for LXR factory patches */
            s->vel = velocities[i];
        }
        printf("%s: pattern %04x\n", factory_preset(ENGINES[a->engine], preset)->name, house[i]);
    }
    fx_stems = 1;
    seq_start();
    unsigned phrase_frames = steps * div_samples(2) * 4u;
    int32_t pcm[2 * CTL];
    uint64_t energy[4] = {0};
    for (unsigned pos = 0; pos < phrase_frames + FS / 4u; pos += CTL) {
        if (song.playing && pos + CTL >= phrase_frames) seq_stop();
        mix_block(pcm, CTL);
        /* Interleaved mono stems for transparent gain and pan at export. */
        for (unsigned j = 0; j < CTL; j++) {
            int32_t frame[4];
            for (unsigned i = 0; i < NELEM(frame); i++) {
                int64_t sample = stem_buf[i][j];
                frame[i] = (int32_t)sample;
                energy[i] += sample * sample;
            }
            if (fwrite(frame, sizeof frame, 1, out) != 1) return 4;
        }
    }
    for (unsigned i = 0; i < NELEM(energy); i++) {
        printf("Track %u energy %llu\n", i + 1, (unsigned long long)energy[i]);
        if (!energy[i]) return 6;
    }
    return 0;
}

int main(int argc, char **argv)
{
    if (argc != 3) return 2;
    const audition_t *a = NULL;
    for (unsigned i = 0; i < NELEM(auditions); i++)
        if (!strcmp(auditions[i].slug, argv[1])) a = &auditions[i];
    if (!a) return 2;

    ui_power_on();
    fm6_init();
    power_on_parts();
    six_native_init();
    song.master_q12 = 4096;
    song.g[G_BPM] = a->bpm;
    song.g[G_RSIZE] = 77;
    song.g[G_DFDBK] = 48;
    song.g[G_DTIME] = 6;
    song.g[G_DPING] = 1;
    FILE *out = fopen(argv[2], "wb");
    if (!out) return 3;
    if (a->engine == ENGI_LXR) {
        song.g[G_CLIP] = song.g[G_PUNCH] = song.g[G_DUCK] = song.g[G_DJF] = 0;
        int result = render_lxr(a, out);
        return fclose(out) && !result ? 5 : result;
    }
    for (unsigned i = 1; i < NTRK; i++) trk[i].p[P_MUTE] = 1;
    track_sound(0, a->engine, a->program, a->level, 0, a->reverb);
    trk[0].p[P_DLY] = a->delay;
    trk[0].p[P_CHOR] = a->phaser;
    if (a->engine == ENGI_OBER) {
        /* OberVave's own low-pass with a lightly resonant edge and a dark room. */
        trk[0].p[P_E0] = 64;
        trk[0].p[P_E1] = 25;
        trk[0].p[P_E5] = 0;
        song.g[G_RTYPE] = 0;
        song.g[G_RSIZE] = 89;
        song.g[G_RDAMP] = 72;
        song.g[G_RPRE] = 22;
        song.g[G_RFILT] = -24;
        song.g[G_RWIDE] = 78;
        song.g[G_CLIP] = song.g[G_PUNCH] = song.g[G_DUCK] = song.g[G_DJF] = 0;
        fx_stems = 1;
    }
    printf("%s\n", factory_preset(ENGINES[a->engine], a->program)->name);
    const unsigned pulse = (FS * 15u + a->bpm * CTL / 2u) / (a->bpm * CTL);
    const unsigned swing = a->engine == ENGI_FMINI ? pulse / 10u : 0;
    const unsigned steps = a->engine == ENGI_OBER ? 80 : 40;
    uint64_t room_energy = 0;
    int32_t pcm[2 * CTL];
    /* A preset load schedules a note reset on the next mixer block. */
    if (a->engine == ENGI_OBER) mix_block(pcm, CTL);
    for (unsigned step = 0; step < steps; step++) {
        phrase_step(a, step);
        unsigned blocks = (step & 1u) ? pulse - swing : pulse + swing;
        for (unsigned block = 0; block < blocks; block++) {
            mix_block(pcm, CTL);
            if (a->engine == ENGI_OBER)
                for (unsigned i = 0; i < CTL; i++) {
                    int64_t wet = stem_fx[0][i];
                    room_energy += wet * wet;
                }
            if (fwrite(pcm, sizeof pcm, 1, out) != 1) return 4;
        }
    }
    if (fclose(out)) return 5;
    if (a->engine == ENGI_OBER) {
        printf("Room return energy %llu\n", (unsigned long long)room_energy);
        if (!room_energy) return 6;
    }
    return 0;
}
