/* Generated reserved-bank tail metadata. No project/song/settings addresses. */
#pragma once
#ifndef JAZZY_EXTERNAL_ASSETS
#define JAZZY_EXTERNAL_ASSETS 0
#endif
#define JAZZY_ASSET_TAIL 73728u
#define JAZZY_ASSET_PAYLOAD 8176u
static const uint32_t JAZZY_ASSET_CRC[2]={1854482957u,3426467486u};
#if JAZZY_EXTERNAL_ASSETS
static uint8_t jazzy_assets_valid;
static const uint8_t *jazzy_asset_at(unsigned off);
static int jazzy_assets_check(void);
#else
#define jazzy_assets_valid 1
#endif
#define JA_JH_FACTORY 0u
#define JA_JS_CFG 2160u
#define JA_JS_WAVE 2736u
#define JA_JS_DRAW 2864u
#define JA_JS_CHOP 3344u
#define JA_JH_WAVE_PACK 3568u
#define JA_JF_PACK 13724u
