/* SPDX-License-Identifier: MPL-2.0
 * Copyright (C) 2026 Kerem Kilic (Ellic Studio)
 * Portions Copyright (C) 2026 john (@johnskiller)
 * Portions Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* HYDRA: a wave-scanning synth after the ASM Hydrasynth (engine 25; it grew from Melodee's WT engine).
 *
 * A voice: OSC 1 and OSC 2 play one wave (SINGLE) or scan a list of eight (SCAN crossfades neighbouring slots, an
 * EMPTY slot is silence), each through two MUTANTs in series (FM-LIN, STACK, SYNC, PW, SQUEEZE, WARP, HARMONIC, each
 * with its dry/wet); OSC 3 plays one wave. RING (two oscillators multiplied) and NOISE (white, pink, brown) join them
 * in the MIXER, where each source has a level and a share sent to FILTER 2 instead of FILTER 1 (ladders, MS-20, LPG,
 * three-pole, vowel). FILTER 2 is a state variable morphing through band or notch, after FILTER 1 (SERIES) or beside
 * it (PARALLEL). ENV 1 (delay, attack, hold, decay, sustain, release) moves both filters. The track's ADSR is the
 * amplitude; its LFO, ENV DEST and MOD slots modulate as for any engine (SHP moves the scans of OSC 1 and 2).
 *
 * The patch: HY_BYTES native bytes a part (hy_patch[]; hydra_patch.h lays them out, hydra_edit.h describes them to the pages).
 * Its eight macros, after the Hydrasynth's: the patch names them and routes each to destinations of its own with depths
 * (hy_macros); E0..E7 are their values, -64..63 (0: the sound as stored), which the knobs, CC 74/71 and the matrix's
 * E1..E8 move. The part state holds the voices and a RAM copy of the waves the patch uses (XIP reads stall the audio
 * loop); the block hook refreshes both when the patch or a macro changes. A voice is costed with every macro wherever
 * it costs most (hy_worst), so no turn of a macro can make the block late.
 */
static inline __attribute__((always_inline)) float hy_clampf(float x, float lo, float hi)
{
    return x < lo ? lo : x > hi ? hi : x;
}
static inline float hy_unit(int32_t raw) { return (float)clamp(raw, 0, 127) * (1.0f / 127.0f); }
/* a PW knee d (0..1 of the cycle) as the phase map's knee and its two slopes, Q16 */
static void hy_knee(hy_mut_t *u, float d)
{
    d = fm_clampf(d, 0.03f, 0.97f);
    u->knee = (uint32_t)(d * 4294967295.0f);
    u->k1 = (uint32_t)(0.5f / d * 65536.0f);
    u->k2 = (uint32_t)(0.5f / (1.0f - d) * 65536.0f);
}
static void hy_mutant(hy_mut_t *u, const uint8_t *q, int32_t macro)
{
    float depth = hy_unit(q[HM_DEPTH] + macro), aux = hy_unit(q[HM_AUX]), ratio = hy_unit(q[HM_RATIO]);
    memset(u, 0, sizeof *u);
    u->mode = q[HM_MODE] < MU_N ? q[HM_MODE] : MU_OFF;
    u->src = q[HM_SRC] < HYS_N ? q[HM_SRC] : HYS_OSC3;
    u->wet = hy_unit(q[HM_WET]);
    switch (u->mode) {
    case MU_FM:                                        /* phase offsets in cycles: up to two, feedback a half */
        u->fm = depth * depth * 2.0f;
        u->fb = aux * aux * 0.5f;
        break;
    case MU_STACK:                                     /* four copies detuned up to +-6 % (about a semitone) */
        u->det = depth * depth * 0.06f;
        break;
    case MU_SYNC:                                      /* 1 .. 16 slave cycles a cycle, a window against clicks */
        u->ratio = (uint32_t)((1.0f + ratio * 7.0f + depth * 8.0f) * 65536.0f);
        u->win = aux;
        break;
    case MU_PW:
        hy_knee(u, 0.5f - depth * 0.47f);
        break;
    case MU_SQZ:
        u->sq = (int32_t)((1.0f + depth * 7.0f) * 65536.0f);
        break;
    case MU_WARP:                                      /* PW within 1, 2, 4 or 8 sections */
        u->sh = (uint8_t)(clamp(q[HM_RATIO], 0, 127) >> 5);
        hy_knee(u, 0.5f - depth * 0.45f);
        break;
    case MU_HARM: {                                    /* harmonic 1 .. up to 16, swept */
        float top = 2.0f + ratio * 14.0f, h = 1.0f + depth * (top - 1.0f);
        u->h = (uint32_t)h;
        u->hfr = h - (float)u->h;
        break;
    }
    }
}
static float hy_ftime(uint32_t v) { return (float)TIME_MS_X10[v & 127u] * (float)FS / (10000.0f * (float)CTL); }
/* the patch as its macros leave it: an assignment moves its destination by depth x the macro's value (e, -64..63) of the
 * destination's range at a full turn; several on one destination add up, then the sum is clamped to its range */
static void hy_macros(const uint8_t *r, const int16_t *e, uint8_t *eff)
{
    int32_t add[HY_NTGT + 1u];
    uint32_t k, g;
    memcpy(eff, r, HY_BYTES);
    memset(add, 0, sizeof add);
    for (k = 0; k < HY_MSLOTS; k++) {
        uint32_t a = r[HY_MA + 2u * k];
        int32_t d = (int32_t)r[HY_MA + 2u * k + 1u] - HY_DEPTH0;
        add[HY_SLOT_TGT(a)] += e[HY_SLOT_MACRO(a)] * d * (int32_t)hy_span(HY_SLOT_TGT(a));
    }
    for (g = 1; g <= HY_NTGT; g++)
        if (add[g]) {
            int32_t x = (add[g] + (add[g] < 0 ? -64 * 127 / 2 : 64 * 127 / 2)) / (64 * 127);
            eff[HY_TGT[g]] = (uint8_t)clamp((int32_t)r[HY_TGT[g]] + x, 0, (int32_t)hy_span(g));
        }
}
/* the patch where its macros could make a voice cost most: a level, FILTER 2's pass and resonance as high as they reach,
 * its cutoff as low, its envelope amount off centre if it can be (what hy_cost reads) */
static void hy_base(hy_part_t *P, const track_t *t, const uint8_t *raw)
{
    hy_base_t *b = &P->b;
    uint8_t r[HY_BYTES];
    uint32_t o, k;
    hy_macros(raw, t->p + P_E0, r);
    memset(b, 0, sizeof *b);
    b->fallback = 0;   /* (hy_prepare grows the state when it can) */
    for (o = 0; o < 2u; o++) {
        const uint8_t *q = r + (o ? HY_O2 : HY_O1);
        b->scanning[o] = q[HO_MODE] != 0 && !b->fallback;
        b->scan[o] = clamp(q[HO_SCAN], 0, 127) << 8;
        b->semi16[o] = (q[HO_SEMI] - HY_SEMI0) * 16;
        b->cent[o] = q[HO_CENT] - HY_CENT0;
        b->key[o] = q[HO_KEY];
    }
    b->semi16[2] = (r[HY_O3_SEMI] - HY_SEMI0) * 16;
    b->cent[2] = r[HY_O3_CENT] - HY_CENT0;
    b->key[2] = r[HY_O3_KEY];
    memcpy(b->m1, r + HY_M1, HM_N);
    for (k = 0; k < 4u; k++) {
        hy_mutant(&b->mut[k], r + HY_M1 + k * HM_N, 0);
        if (b->mut[k].mode == MU_STACK)
            b->stack[k >> 1] = (uint8_t)(k + 1u);
    }
    for (k = 0; k < HYS_N; k++) {
        float l = hy_unit(r[HY_LVL + k]);
        b->lvl[k] = l * l * 0.8f;
        b->bal[k] = hy_unit(r[HY_BAL + k]);
    }
    b->ring_a = r[HY_RING_A] < 3u ? r[HY_RING_A] : 0;
    b->ring_b = r[HY_RING_B] < 3u ? r[HY_RING_B] : 1;
    b->noise = r[HY_NOISE] < 3u ? r[HY_NOISE] : 0;
    b->route = r[HY_ROUTE] != 0;
    for (k = 0; k < 4u; k++)                           /* the FM sources the mutants read */
        if (b->mut[k].mode == MU_FM)
            b->src_used[b->mut[k].src] = 1;
    if (b->lvl[HYS_RING] > 0.0f)
        b->src_used[HYS_RING] = 1;
    if (b->src_used[HYS_RING])
        b->src_used[b->ring_a] = b->src_used[b->ring_b] = 1;
    for (o = 0; o < 3u; o++)
        b->on[o] = b->lvl[o] > 0.0f || b->src_used[o];
    for (k = 0; k < HYS_N; k++)
        if (b->lvl[k] > 0.0f) {
            b->mix[b->nmix++] = (uint8_t)k;
            b->bus2 |= b->bal[k] > 0.0f;
        }
    b->noise_on = b->lvl[HYS_NOISE] > 0.0f || b->src_used[HYS_NOISE];
    b->f1type = r[HY_F1_TYPE] < F1_N ? r[HY_F1_TYPE] : F1_LAD24;
    b->f1cut = (float)clamp(r[HY_F1_CUT], 0, 127);
    b->f1res = hy_unit(r[HY_F1_RES]);
    b->f1drive = 1.0f + hy_unit(r[HY_F1_DRIVE]) * 7.0f;
    b->f1post = r[HY_F1_DPOS] != 0;
    b->f1env = (float)(clamp(r[HY_F1_ENV], 0, 2 * HY_ENV0) - HY_ENV0) * (96.0f / 63.0f);   /* up to ~7 octaves */
    b->f1key = (float)clamp(r[HY_F1_KEY], 0, 200) * 0.01f * (127.0f / 9.0589f / 12.0f);   /* index a semitone */
    b->f1vel = hy_unit(r[HY_F1_VEL]) * 48.0f;
    b->f2notch = r[HY_F2_TYPE] != 0;
    b->f2morph = hy_unit(r[HY_F2_MORPH]);
    b->f2cut = (float)clamp(r[HY_F2_CUT], 0, 127);
    b->f2res = hy_unit(r[HY_F2_RES]);
    b->f2env = (float)(clamp(r[HY_F2_ENV], 0, 2 * HY_ENV0) - HY_ENV0) * (96.0f / 63.0f);
    b->f2key = (float)clamp(r[HY_F2_KEY], 0, 200) * 0.01f * (127.0f / 9.0589f / 12.0f);
    b->f2open = !b->f2notch && !r[HY_F2_MORPH] && r[HY_F2_CUT] >= 127 && !r[HY_F2_RES] &&
                r[HY_F2_ENV] == HY_ENV0 && !r[HY_F2_KEY];
    b->amp = hy_unit(r[HY_AMP]);
    b->e1sc[0] = (float)(clamp(r[HY_E1_SC1], 0, 2 * HY_ENV0) - HY_ENV0) * (127.0f * 256.0f / 63.0f);
    b->e1sc[1] = (float)(clamp(r[HY_E1_SC2], 0, 2 * HY_ENV0) - HY_ENV0) * (127.0f * 256.0f / 63.0f);
    b->e1mu = (float)(clamp(r[HY_E1_MU1], 0, 2 * HY_ENV0) - HY_ENV0) * (127.0f / 63.0f);
    b->e1dly = (uint16_t)(r[HY_E1_DLY] ? fm_minf(hy_ftime(r[HY_E1_DLY]), 65535.0f) : 0.0f);
    b->e1hld = (uint16_t)(r[HY_E1_HLD] ? fm_minf(hy_ftime(r[HY_E1_HLD]), 65535.0f) : 0.0f);
    b->e1atk[0] = (float)ENV_LIN[r[HY_E1_ATK] & 127u] * (1.0f / 16777216.0f);
    b->e1dec = (float)ENV_EXP[r[HY_E1_DEC] & 127u] * (1.0f / 65536.0f);
    b->e1rel = (float)ENV_EXP[r[HY_E1_REL] & 127u] * (1.0f / 65536.0f);
    b->e1sus = hy_unit(r[HY_E1_SUS]);
}
static float hy_env1(const hy_base_t *b, hy_voice_t *s, int gate)
{
    if (!gate && s->e1stage)
        s->e1stage = 5;
    switch (s->e1stage) {
    case 1:
        if (s->e1wait) { s->e1wait--; break; }
        s->e1stage = 2;                                /* fall through */
    case 2:
        s->e1 += b->e1atk[0];
        if (s->e1 >= 1.0f) { s->e1 = 1.0f; s->e1stage = 3; s->e1wait = b->e1hld; }
        break;
    case 3:
        if (s->e1wait) { s->e1wait--; break; }
        s->e1stage = 4;                                /* fall through */
    case 4:
        s->e1 += (b->e1sus - s->e1) * b->e1dec;
        break;
    case 5:
        s->e1 -= s->e1 * b->e1rel;
        if (s->e1 < 1e-4f) { s->e1 = 0.0f; s->e1stage = 0; }
        break;
    }
    return s->e1;
}

/* an oscillator for one block, as the producer (CPU0) prepares it: indices, not pointers, so the batch descriptor
 * stays small (and one size on the host) */
#define HY_NOMUT 255u
#define HY_MU1 4u                                      /* (m1: the voice's own MUTANT 1, moved by ENV 1) */
typedef struct {
    uint8_t a, b, m1, m2;                              /* the rows read; its phase mutants in order (0..3, HY_MU1) */
    int32_t fr;                                        /* a scan's crossfade (Q15) */
    float g, det, swet;                                /* its level (an EMPTY slot fades it), STACK's detune, copies */
    uint32_t inc;
} hy_osc_t;
typedef struct {                                       /* one voice's block, ready to render */
    hy_osc_t o[2];
    uint32_t inc3;
    float gain1;                                       /* FILTER 1: its input gain, then by its type */
    union {
        struct { float g1, k1, rcp1; } lad;            /* the ladders, FAT, three-pole */
        struct { float a1, a2, a3, kd1, lpg; } svf;    /* MS-20, LPG */
        struct { float a1[3], a2[3], a3[3], k; } vow;  /* VOWEL: three band passes */
    } f1;
    float sa1, sa2, sa3, sk, lp, bp, hp;               /* FILTER 2 */
    float amp0, amp1, scale;
    uint8_t f2mod;                                     /* the track's FLT modulation moves FILTER 2 (no pass-by) */
} hy_blk_t;
typedef struct { hy_part_t *P; hy_voice_t *voice; uint16_t dk; uint8_t n, vi; hy_blk_t c; } hy_job_t;   /* (dk: the voice's dither row) */

typedef struct {                                       /* an oscillator, as the kernel reads it */
    const int16_t *a, *b;
    int32_t fr;
    float g;
    uint32_t inc, sinc[4];                             /* its increment, the STACK copies' */
    const hy_mut_t *m1, *m2;
    float swet, srcp;                                  /* STACK's copies, 1 / what they sum to (a divide once a block) */
} hy_oview_t;

static inline __attribute__((always_inline)) int32_t hy_rdi(const int16_t *a, const int16_t *b, int32_t fr, uint32_t q)
{
    uint32_t i = q >> 24, nx = (i + 1u) & (HY_PTS - 1u);
    int32_t t = (int32_t)((q >> 9) & 0x7fffu);
    int32_t x = a[i] + (((a[nx] - a[i]) * t) >> 15);
    if (fr) {
        int32_t y = b[i] + (((b[nx] - b[i]) * t) >> 15);
        x += ((y - x) * fr) >> 15;
    }
    return x;
}
static inline __attribute__((always_inline)) float hy_rd(const int16_t *a, const int16_t *b, int32_t fr, uint32_t q)
{
    return (float)hy_rdi(a, b, fr, q) * (1.0f / 32768.0f);
}
static inline __attribute__((always_inline)) uint32_t hy_pw(const hy_mut_t *u, uint32_t q)
{
    return q < u->knee ? (uint32_t)(((uint64_t)q * u->k1) >> 16)
                       : 0x80000000u + (uint32_t)(((uint64_t)(q - u->knee) * u->k2) >> 16);
}
/* a mutant's phase (and the gain SYNC's window gives) */
static inline __attribute__((always_inline)) uint32_t hy_mphase(const hy_mut_t *u, uint32_t q, const float *src,
                                                                 float self, float *gain)
{
    switch (u->mode) {
    case MU_FM: {
        float c = src[u->src] * u->fm + self * u->fb;
        c -= fm_floorf(c);
        return q + (uint32_t)(c * 4294967040.0f);
    }
    case MU_SYNC:
        if (u->win > 0.0f) {                           /* (a parabola for sin(pi x): no table in flash to read) */
            float x = (float)q * (1.0f / 4294967296.0f);
            *gain = 1.0f - u->win * (1.0f - 4.0f * x * (1.0f - x));
        }
        return (uint32_t)(((uint64_t)q * u->ratio) >> 16);
    case MU_PW:
        return hy_pw(u, q);
    case MU_SQZ: {
        int64_t c = ((int64_t)(int32_t)(q ^ 0x80000000u) * u->sq) >> 16;
        c = c > 0x7FFFFFFF ? 0x7FFFFFFF : c < -0x7FFFFFFF ? -0x7FFFFFFF : c;
        return (uint32_t)(int32_t)c ^ 0x80000000u;
    }
    case MU_WARP:
        if (!u->sh)
            return hy_pw(u, q);
        return (q & ~(0xFFFFFFFFu >> u->sh)) | (hy_pw(u, q << u->sh) >> u->sh);
    case MU_HARM:
        return q * u->h;
    }
    return q;
}
/* a mutant's read: HARMONIC crossfades its harmonic into the next */
static inline __attribute__((always_inline)) float hy_mread(const hy_oview_t *o, const hy_mut_t *u, uint32_t q,
                                                             uint32_t mq)
{
    float x = hy_rd(o->a, o->b, o->fr, mq);
    if (u->mode == MU_HARM && u->hfr > 0.0f)
        x += (hy_rd(o->a, o->b, o->fr, q * (u->h + 1u)) - x) * u->hfr;
    return x;
}
/* phase q through the oscillator's mutants (series, each blended with what reached it by its WET) */
static inline __attribute__((always_inline)) float hy_chain(const hy_oview_t *o, uint32_t q, const float *src, float self)
{
    const hy_mut_t *u1 = o->m1, *u2 = o->m2;
    float g = 1.0f, y, x;
    uint32_t q1, q2;
    if (!u1)
        return hy_rd(o->a, o->b, o->fr, q);
    q1 = hy_mphase(u1, q, src, self, &g);
    y = hy_mread(o, u1, q, q1) * g;
    if (u1->wet < 1.0f) {
        x = hy_rd(o->a, o->b, o->fr, q);
        y = x + (y - x) * u1->wet;
    }
    if (!u2)
        return y;
    g = 1.0f;
    q2 = hy_mphase(u2, q1, src, self, &g);
    x = hy_mread(o, u2, q1, q2) * g;
    return y + (x - y) * u2->wet;
}
/* an oscillator with mutants: its own phase through the chain, then STACK's four copies (one copy of the chain's
 * code serves all five) */
static __attribute__((noinline, section(".text.jh"))) float hy_osc(const hy_oview_t *o, uint32_t *ph, uint32_t *sp,
                                                           const float *src, float self)
{
    float x = 0.0f, c = 0.0f;
    uint32_t j, n = o->swet > 0.0f ? 5u : 1u;
    if (!o->m1) {                                      /* STACK alone: the copies summed whole (every value is exact in
                                                        * a float, so this is the loop below without its conversions) */
        const int16_t *a = o->a, *b = o->b;
        int32_t fr = o->fr, sum = 0, one;
        uint32_t q = *ph += o->inc;
        one = hy_rdi(a, b, fr, q);
        for (j = 0; j < 4u; j++) {
            q = sp[j] += o->sinc[j];
            sum += hy_rdi(a, b, fr, q);
        }
        x = (float)one * (1.0f / 32768.0f);
        c = (float)sum * (1.0f / 32768.0f);
        return (x + c * o->swet) * o->srcp * o->g;
    }
    for (j = 0; j < n; j++) {
        uint32_t q;
        float y;
        if (!j) {
            *ph += o->inc;
            q = *ph;
        } else {
            sp[j - 1u] += o->sinc[j - 1u];
            q = sp[j - 1u];
        }
        y = hy_chain(o, q, src, self);
        if (!j)
            x = y;
        else
            c += y;
    }
    if (n > 1u)
        x = (x + c * o->swet) * o->srcp;
    return x * o->g;
}

/* FILTER 1: an n-pole ladder (trapezoidal one-poles, the feedback solved without delay, its input saturated);
 * y[0..n-1] its stages' outputs, y[4] the first stage's input (the three-pole modes mix them) */
static inline __attribute__((always_inline)) float hy_ladder(float *z, uint32_t n, float x, const hy_blk_t *c, float *y)
{
    float g = c->f1.lad.g1, sigma, u, d;
    uint32_t j;
    sigma = n == 4u ? z[3] + g * (z[2] + g * (z[1] + g * z[0])) :
            n == 3u ? z[2] + g * (z[1] + g * z[0]) : z[1] + g * z[0];
    sigma *= 1.0f - g;
    u = p5_fast_softclip((x * c->gain1 - c->f1.lad.k1 * sigma) * c->f1.lad.rcp1);
    y[4] = u;
    for (j = 0; j < n; j++) {
        d = g * (u - z[j]);
        y[j] = z[j] + d;
        z[j] = fm_flush(hy_clampf(y[j] + d, -2.0f, 2.0f));
        u = y[j];
    }
    return u;
}
/* a trapezoidal state variable (A. Simper): lp, bp, hp from x; ic: its two integrators */
static inline __attribute__((always_inline)) void hy_svf(float *ic, float x, float a1, float a2, float a3, float *lp,
                                                          float *bp)
{
    float v3 = x - ic[1], v1 = a1 * ic[0] + a2 * v3, v2 = ic[1] + a2 * ic[0] + a3 * v3;
    ic[0] = fm_flush(2.0f * v1 - ic[0]);
    ic[1] = fm_flush(2.0f * v2 - ic[1]);
    *lp = v2;
    *bp = v1;
}
static __attribute__((noinline, section(".text.jh"))) float hy_filter1(hy_voice_t *s, uint32_t type, float x, const hy_blk_t *c)
{
    float y[5], lp, bp;
    switch (type) {
    case F1_LAD12: case F1_FAT12:
        return hy_ladder(s->z, 2, x, c, y);
    case F1_LAD24: case F1_FAT24:
        return hy_ladder(s->z, 4, x, c, y);
    case F1_3LP:
        return hy_ladder(s->z, 3, x, c, y);
    case F1_3BP:
        hy_ladder(s->z, 3, x, c, y);
        return (y[0] - y[1]) * 2.0f;
    case F1_3HP:                                       /* (the binomial mix of the stages: three-pole high pass) */
        hy_ladder(s->z, 3, x, c, y);
        return y[4] - 3.0f * y[0] + 3.0f * y[1] - y[2];
    case F1_MSLP: case F1_MSHP: case F1_LPG: {         /* MS-20: the band integrator saturates (its scream) */
        float in = p5_fast_softclip(x * c->gain1);
        hy_svf(s->z, in, c->f1.svf.a1, c->f1.svf.a2, c->f1.svf.a3, &lp, &bp);
        if (type == F1_LPG)
            return lp * c->f1.svf.lpg;
        s->z[0] = p5_fast_softclip(s->z[0]);
        return p5_fast_softclip(type == F1_MSHP ? in - c->f1.svf.kd1 * bp - lp : lp);   /* (its output stage clips too) */
    }
    case F1_VOWEL: {
        float b0, b1, b2;
        hy_svf(s->z, x, c->f1.vow.a1[0], c->f1.vow.a2[0], c->f1.vow.a3[0], &lp, &b0);
        hy_svf(s->z + 2, x, c->f1.vow.a1[1], c->f1.vow.a2[1], c->f1.vow.a3[1], &lp, &b1);
        hy_svf(s->z + 4, x, c->f1.vow.a1[2], c->f1.vow.a2[2], c->f1.vow.a3[2], &lp, &b2);
        return (b0 + b1 * 0.7f + b2 * 0.45f) * c->f1.vow.k;
    }
    }
    return x;
}

static inline float hy_g(float idx)                    /* a cutoff index (0..127, CUTOFF_HZ) as a TPT one-pole's G */
{
    uint32_t i;
    float g;
    idx = fm_clampf(idx, 0.0f, 126.99f);
    i = (uint32_t)idx;
    g = P5_TPT_G[i];
    return g + (P5_TPT_G[i + 1u] - g) * (idx - (float)i);
}
static void hy_svf_coef(float idx, float k, float *a1, float *a2, float *a3)
{
    float G = hy_g(idx), g = G / (1.0f - G);
    *a1 = 1.0f / (1.0f + g * (g + k));
    *a2 = g * *a1;
    *a3 = g * *a2;
}
/* the vowels' formants (Hz): A E I O U; CUT walks them */
static const uint16_t HY_VOWEL[5][3] = {{730, 1090, 2440}, {530, 1840, 2480}, {270, 2290, 3010}, {570, 840, 2410},
                                        {300, 870, 2240}};
static void hy_coef1(hy_blk_t *c, const hy_base_t *b, float idx)
{
    uint32_t type = b->f1type;
    float res = b->f1res;
    c->gain1 = 1.0f;
    if (type == F1_VOWEL) {
        float pos = fm_clampf(idx, 0.0f, 127.0f) * (4.0f / 127.0f), f;
        uint32_t i = (uint32_t)pos, j;
        if (i > 3u) i = 3u;
        pos -= (float)i;
        c->f1.vow.k = 0.12f + (1.0f - res) * 0.5f;
        for (j = 0; j < 3u; j++) {
            f = (float)HY_VOWEL[i][j] + ((float)HY_VOWEL[i + 1u][j] - (float)HY_VOWEL[i][j]) * pos;
            hy_svf_coef(127.0f * fm_log2f(f * (1.0f / 30.0f)) * (1.0f / 9.0589f), c->f1.vow.k, &c->f1.vow.a1[j],
                        &c->f1.vow.a2[j], &c->f1.vow.a3[j]);
        }
        return;
    }
    if (type == F1_MSLP || type == F1_MSHP || type == F1_LPG) {
        c->f1.svf.kd1 = 2.0f - res * 1.96f;
        hy_svf_coef(idx, c->f1.svf.kd1, &c->f1.svf.a1, &c->f1.svf.a2, &c->f1.svf.a3);
        c->f1.svf.lpg = fm_clampf(idx * (1.0f / 100.0f), 0.0f, 1.0f);
        c->f1.svf.lpg *= c->f1.svf.lpg;
        c->gain1 = 1.0f + res * 0.6f;
        return;
    }
    c->f1.lad.g1 = hy_g(idx);
    {
        float g = c->f1.lad.g1, gn = type == F1_LAD12 || type == F1_FAT12 ? g * g : type >= F1_3LP ? g * g * g : g * g * g * g;
        float k = res * (type == F1_LAD12 || type == F1_FAT12 ? 1.9f : type >= F1_3LP ? 7.8f : 4.4f);
        c->f1.lad.k1 = k;
        c->f1.lad.rcp1 = 1.0f / (1.0f + k * gn);
        /* the level resonance takes from the pass band, partly given back (FAT: most of it) */
        c->gain1 = 1.0f + k * (type == F1_FAT12 || type == F1_FAT24 ? 0.75f : type >= F1_3LP ? 0.3f : 0.2f);
    }
}

/* the half-band decimator (27 taps, Kaiser: -43 dB from 26.5 kHz, flat to 17.6 kHz): its odd taps, the centre */
static const float HY_HB[7] __attribute__((section(".dsp_tables"))) = {2.164955030e-03f, -6.402938631e-03f, 1.392820774e-02f, -2.661780621e-02f,
                               4.886781318e-02f, -9.661241257e-02f, 3.148480322e-01f};
static inline __attribute__((always_inline)) float hy_decimate(const float *o, const float *e, uint32_t dp)
{
    float y = 0.4996483f * e[(dp - 6u) & 7u];
    for (uint32_t i = 0; i < 7u; i++)
        y += HY_HB[i] * (o[(dp - 13u + i) & 15u] + o[(dp - i) & 15u]);
    return y;
}
/* an oscillator without mutants: the read alone (no calls) */
static inline __attribute__((always_inline)) float hy_plain(const hy_oview_t *o, uint32_t *ph)
{
    *ph += o->inc;
    return hy_rd(o->a, o->b, o->fr, *ph) * o->g;
}
/* the sources at one (sub)sample: noise, the oscillators, ring; into the MIXER's two buses */
static inline __attribute__((always_inline)) void hy_sources(const hy_base_t *b, hy_voice_t *s, const hy_oview_t *ov,
                                                              const int16_t *w3, uint32_t inc3, float *x1, float *x2)
{
    float *src = s->out, a = 0.0f, d = 0.0f;
    uint32_t k, *ph = s->ph;
    if (b->noise_on) {
        float w = (float)(int32_t)noise32(&s->noise) * (1.0f / 2147483648.0f);
        if (b->noise == 1u) {                          /* pink (P. Kellet's three poles), brown (a leaky sum) */
            s->pink[0] = 0.99765f * s->pink[0] + w * 0.0990460f;
            s->pink[1] = 0.96300f * s->pink[1] + w * 0.2965164f;
            s->pink[2] = 0.57000f * s->pink[2] + w * 1.0526913f;
            w = (s->pink[0] + s->pink[1] + s->pink[2] + w * 0.1848f) * 0.25f;
        } else if (b->noise == 2u) {
            s->brown = s->brown * 0.985f + w * 0.12f;
            w = s->brown * 1.6f;
        }
        src[HYS_NOISE] = w;
    }
    if (b->on[2]) {
        ph[2] += inc3;
        src[HYS_OSC3] = hy_rd(w3, w3, 0, ph[2]);
    }
    if (b->on[1])                                      /* (an oscillator's own last sample: its FEEDBACK) */
        src[HYS_OSC2] = ov[1].m1 || ov[1].swet > 0.0f ? hy_osc(&ov[1], &ph[1], s->sp[1], src, src[HYS_OSC2])
                                                       : hy_plain(&ov[1], &ph[1]);
    if (b->on[0])
        src[HYS_OSC1] = ov[0].m1 || ov[0].swet > 0.0f ? hy_osc(&ov[0], &ph[0], s->sp[0], src, src[HYS_OSC1])
                                                       : hy_plain(&ov[0], &ph[0]);
    if (b->src_used[HYS_RING])
        src[HYS_RING] = src[b->ring_a] * src[b->ring_b];
    for (k = 0; k < b->nmix; k++) {                    /* the MIXER: FILTER 1's share and FILTER 2's */
        uint32_t j = b->mix[k];
        float v = src[j] * b->lvl[j], e = v * b->bal[j];
        a += v - e;
        d += e;
    }
    *x1 = a;
    *x2 = d;
}
static const float HY_SPREAD[4] __attribute__((section(".dsp_tables"))) = {-1.0f, -0.5f, 0.5f, 1.0f};
/* One voice's block (the batch job: CPU1 or CPU0). It runs from internal RAM (.audio_text) and reads only RAM:
 * from XIP flash CPU1 rendered a voice 2.4x slower than CPU0 alone (both cores' fetches share the flash cache), and
 * the whole render on CPU1 (its block set-up too) still 1.5x. CPU0 prepares the block (hy_render); this owns the
 * voice's state until the batch joins and reads the part's prepared values, its wave copies, P5_TANH and HY_HB */
static __attribute__((noinline, section(".text.jh"))) void hy_kernel(const void *data, int32_t *out)
{
    const hy_job_t *jb = data;
    hy_part_t *P = jb->P;
    const hy_base_t *b = &P->b;
    const hy_blk_t *c = &jb->c;
    hy_voice_t *s = jb->voice;
    hy_oview_t ov[2];
    uint32_t i, o, k, f1 = b->f1type, n = jb->n;
    
    float dc = s->dc, scale = c->scale, level = 0.0f;
    int parallel_scan = b->route && b->bus2 && b->scanning[0] && b->scanning[1];
    const float scan_headroom = 0.055f;
    /* The scanned waves can differ sharply in level as they meet at the
     * output of the two filters. Keep headroom without changing the sweep. */
    if (parallel_scan && s->scan_level > scan_headroom)
        scale *= scan_headroom / s->scan_level;
    for (o = 0; o < 2u; o++) {
        const hy_osc_t *r = &c->o[o];
        hy_oview_t *w = &ov[o];
        w->a = jh_wave(P->tag[r->a]);
        w->b = jh_wave(P->tag[r->b]);
        w->fr = r->fr;
        w->g = r->g;
        w->inc = r->inc;
        w->swet = r->swet;
        w->m1 = r->m1 == HY_MU1 ? &s->mu1 : r->m1 < 4u ? &b->mut[r->m1] : 0;
        w->m2 = r->m2 < 4u ? &b->mut[r->m2] : 0;
        w->srcp = 1.0f / (1.0f + r->swet * 2.0f);
        if (r->swet > 0.0f)
            for (k = 0; k < 4u; k++)
                w->sinc[k] = (uint32_t)((float)r->inc * (1.0f + HY_SPREAD[k] * r->det));
    }
    for (i = 0; i < n; i++) {
        float x1, x2, y, lp, bp, amp;
        hy_sources(b, s, ov, jh_wave(P->tag[b->row3]), c->inc3, &x1, &x2);
        if (s->os) {                                   /* 2x: this was the even half; the odd, then one of the two */
            uint32_t dp = s->dp = (uint8_t)((s->dp + 1u) & 15u);
            s->deven[0][dp & 7u] = x1;
            s->deven[1][dp & 7u] = x2;
            hy_sources(b, s, ov, jh_wave(P->tag[b->row3]), c->inc3, &s->dodd[0][dp], &s->dodd[1][dp]);
            x1 = hy_decimate(s->dodd[0], s->deven[0], dp);
            x2 = b->bus2 ? hy_decimate(s->dodd[1], s->deven[1], dp) : 0.0f;
        }
        if (!b->f1post)
            x1 = p5_fast_softclip(x1 * b->f1drive);
        y = hy_filter1(s, f1, x1, c);
        if (b->f1post)
            y = p5_fast_softclip(y * b->f1drive);
        if (!b->route) {                               /* SERIES: FILTER 2 after FILTER 1 */
            x2 += y;
            y = 0.0f;
        }
        if (b->f2open && !c->f2mod) {
            y += x2;
        } else {
            hy_svf(s->f2, x2, c->sa1, c->sa2, c->sa3, &lp, &bp);
            y += c->lp * lp + c->bp * bp + c->hp * (x2 - c->sk * bp - lp);
        }
        y = hy_clampf(y, -4.0f, 4.0f);
        if (parallel_scan)
            level += fm_fabsf(y);
        dc += (y - dc) * HY_COUPLE;
        amp = c->amp0 + (c->amp1 - c->amp0) * (float)i * (1.0f / CTL);
        out[i] += (int32_t)((y - dc) * amp * scale);
    }
    s->dc = fm_flush(dc);
    if (parallel_scan) {
        level *= (1.0f / CTL);
        float delta = level - s->scan_level;
        s->scan_level += delta * (delta > 0.0f ? 0.125f : 0.0125f);
    }
}

/* CPU0: the voice's block made ready (ENV 1, pitch, the scans, the mutants, the filters' coefficients), then the
 * kernel: in the batch (mix.c: CPU1 or CPU0 by cost) or at once */
static void hy_render(track_t *t, voice_t *v, int32_t *out, uint32_t n, const vmod_t *m)
{
    if(!jazzy_assets_valid)return;
    hy_part_t *P = hy_part((uint32_t)(t - trk));
    const hy_base_t *b;
    hy_voice_t *s;
    hy_job_t jb;
    hy_blk_t *c = &jb.c;
    uint32_t o;
    float e1, idx;
    if (!P || !n)
        return;
    if (!P->valid)
        hy_block(t);
    b = &P->b;
    jb.P = P; jb.voice = jh_voice(t);
    jb.n = (uint8_t)n;
    jb.dk = (uint16_t)m->amp1;
    jb.vi = (uint8_t)((uint32_t)(v - t->v) % 1u);
    s = jh_voice(t);
    e1 = hy_env1(b, s, v->gate);
    for (o = 0; o < 2u; o++) {                         /* OSC 1, 2: pitch, the scan, the mutants */
        hy_osc_t *r = &c->o[o];
        const hy_mut_t *u1 = &b->mut[o * 2u], *u2 = &b->mut[o * 2u + 1u], *m1, *m2;
        if (!o && b->e1mu != 0.0f && u1->mode) {      /* ENV 1 -> MUTANT 1's DEPTH: this voice's own */
            hy_mutant(&s->mu1, b->m1, (int32_t)(e1 * b->e1mu));
            u1 = &s->mu1;
        }
        int32_t p16 = 960 + (m->pitch16 - 960) * b->key[o] / 100 + b->semi16[o];
        r->inc = cents_inc(p16, b->cent[o], m->fine);
        if (b->scanning[o]) {                          /* SCAN: 0..127 over the eight slots; SHP moves it */
            int32_t pos = clamp(b->scan[o] + (m->shape - (64 << 8)) + (int32_t)(e1 * b->e1sc[o]), 0, 127 << 8) * 7;
            int32_t sl = pos / (127 << 8);
            int32_t f = (int32_t)(((pos - sl * (127 << 8)) << 7) / 127);   /* Q15 */
            const uint8_t *q = jh_patch(t)->raw + (o ? HY_O2 : HY_O1) + HO_L0;
            int ea, eb;                                /* EMPTY slots: silence, faded into */
            if (sl >= 7) { sl = 7; f = 0; }
            ea = !q[sl];
            eb = !f || !q[sl + 1];
            r->a = (uint8_t)(b->row0[o] + (uint32_t)(ea && !eb ? sl + 1 : sl));
            r->b = (uint8_t)(b->row0[o] + (uint32_t)(eb ? sl : sl + 1));
            r->fr = ea || eb ? 0 : f;
            r->g = ea ? (eb ? 0.0f : (float)f * (1.0f / 32768.0f)) : eb && f ? 1.0f - (float)f * (1.0f / 32768.0f) : 1.0f;
        } else {
            r->a = r->b = b->row0[o];
            r->fr = 0;
            r->g = 1.0f;
        }
        m1 = u1->mode && u1->mode != MU_STACK ? u1 : u2->mode && u2->mode != MU_STACK ? u2 : 0;
        m2 = m1 == u1 && u2->mode && u2->mode != MU_STACK ? u2 : 0;
        r->m1 = !m1 ? HY_NOMUT : m1 == &s->mu1 ? HY_MU1 : (uint8_t)(m1 - b->mut);
        r->m2 = !m2 ? HY_NOMUT : (uint8_t)(m2 - b->mut);
        r->swet = r->det = 0.0f;
        if (b->stack[o]) {
            const hy_mut_t *st = &b->mut[b->stack[o] - 1u];
            r->swet = st->wet;
            r->det = st->det;
        }
        if (s->thin) {
            r->m1 = r->m2 = HY_NOMUT;
            r->swet = r->det = 0.0f;
        }
    }
    c->inc3 = b->on[2] ? cents_inc(960 + (m->pitch16 - 960) * b->key[2] / 100 + b->semi16[2], b->cent[2], m->fine) : 0u;
    /* the filters' cutoffs: the knob, ENV 1, the key (from middle C), velocity, the track's FLT modulation */
    idx = b->f1cut + e1 * b->f1env + (float)(m->pitch16 - 960) * (1.0f / 16.0f) * b->f1key +
          ((float)v->vel - 64.0f) * (1.0f / 64.0f) * b->f1vel + (float)m->cutoff * (1.0f / 256.0f);
    hy_coef1(c, b, idx);
    c->f2mod = m->cutoff != 0;
    if (!b->f2open || c->f2mod) {                      /* (passed by, the kernel reads none of FILTER 2's) */
        idx = b->f2cut + e1 * b->f2env + (float)(m->pitch16 - 960) * (1.0f / 16.0f) * b->f2key +
              (float)m->cutoff * (1.0f / 256.0f);
        c->sk = 2.0f - b->f2res * 1.9f;
        hy_svf_coef(idx, c->sk, &c->sa1, &c->sa2, &c->sa3);
                                                       /* FILTER 2's morph: LP > BP > HP, or LP > NOTCH > HP
                                                        * (the notch: low and high together) */
        float mo = b->f2morph * 2.0f;
        if (b->f2notch) {
            c->lp = mo <= 1.0f ? 1.0f : 2.0f - mo;
            c->hp = mo <= 1.0f ? mo : 1.0f;
            c->bp = 0.0f;
        } else {
            c->lp = mo <= 1.0f ? 1.0f - mo : 0.0f;
            c->bp = mo <= 1.0f ? mo : 2.0f - mo;
            c->hp = mo <= 1.0f ? 0.0f : mo - 1.0f;
        }
    }
    c->amp0 = (float)m->amp0 * (1.0f / 32768.0f);
    c->amp1 = (float)m->amp1 * (1.0f / 32768.0f);
    c->scale = b->amp * (16384.0f);
    if (s->os) {                                       /* (twice the rate: half the steps) */
        c->o[0].inc >>= 1;
        c->o[1].inc >>= 1;
        c->inc3 >>= 1;
    }

    {                                                  /* (XIP to RAM: past a direct branch's reach) */
        void (*volatile run)(const void *, int32_t *) = hy_kernel;
        run(&jb, out);
    }
}

