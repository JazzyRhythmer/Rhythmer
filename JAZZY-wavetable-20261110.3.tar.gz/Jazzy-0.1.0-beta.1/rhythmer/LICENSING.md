# Felucca licensing

Felucca is free software, licensed under the GNU General Public License, version 3 only
(`GPL-3.0-only`, full text in `LICENSE`). That covers the code and its own assets. A few
bundled or ported parts keep their own licences; they are listed below, and their licence
texts are in `LICENSES/`.

Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments
Copyright (C) 2026 Juan Ignacio Antonucci (Juan Jiant) — JIANT FM, the fork of Felucca in this tree: its own files
and its modifications. A file's header says which: "Copyright (C) 2026 Juan Ignacio Antonucci (Juan Jiant)" where the
file is mostly JIANT's, "Portions Copyright (C) 2026 Juan Ignacio Antonucci (Juan Jiant)" where it is mostly Felucca's
and JIANT changed it; Felucca's line stays wherever it was. The licence is the same: GPL-3.0-only.

## What is GPL-3.0-only

Every file in this tree that carries an `SPDX-License-Identifier: GPL-3.0-only` header:

- the firmware: `firmware/` (app, HAL, update loader)
- the build script and tools: `build.sh`, `tools/`
- the web pages (installer, editor, the browser emulator `web/emu/`) and their tests: `web/` (not the Fukiai and DotGothic16 fonts, below)
- the host tests: `tests/`
- JIANT FM's interface art: `assets/ui-art/`, `assets/ui-shapes/` and the concept image `docs/jiant-fm-ui-concept.jpg`
  (by JIANT's author, under GPL-3.0-only like the rest of JIANT)

One source file is a port and keeps the licence of its original: `firmware/src/fm6_core.c`
(msfa, Apache-2.0). The firmware built with it is GPL-3.0-only as a whole. (The PHYS engine, ported
from DaisySP and Rings, MIT, was removed in FELUCCA TONIC.)

You may use, study, change and share Felucca under the GPL. If you distribute Felucca, or
firmware derived from it, you must also give your recipients its complete corresponding
source under the same licence. That includes devices that ship with modified Felucca inside.

## Hügelton Instruments' own work

All by Hügelton Instruments (Leo Kuroshita), in this tree:

| What | Licence | Where |
| --- | --- | --- |
| Felucca: firmware, tools, web pages, tests | GPL-3.0-only | `LICENSE` |
| The PHASE engine's waveforms: a C port of the oscillator of CrispyZebra (<https://github.com/hugelton/CrispyZebra>) | GPL-3.0 | `firmware/src/eng_phase.c` |
| The DRUM voices and kit | GPL-3.0-only | `firmware/src/drum_voice.c`, `firmware/src/eng_drum.c` |
| The Hügelton Sample Pack: Felucca's drum sounds, made by `tools/gen_waves.py` (not CC0; JIANT builds none of them in: SLICE, which played its BREAK, is retired) | GPL-3.0-only | `tools/gen_waves.py` |
| The Fukiai icon font (<https://github.com/hugelton/Fukiai>): the firmware's icons (rasterised at build time by `tools/gen_aa_icons.py`) and the web editor's | MIT | `web/fukiai.ttf`, `LICENSES/MIT-Fukiai.txt`, `web/FUKIAI-LICENSE.txt` |
| fm1-clk320-probe by curist (<https://github.com/curist/fm1-clk320-probe>): the switch from the FM-1's 360 MHz to JieLi's rated 320 MHz behind MENU > SYSTEM > CPU CLOCK (JIANT 0.9.12; the check of the clock registers and the switch), unchanged; its sequence after the JieLi AC79 SDK's `sys_clock_update` (Apache-2.0) | MIT | `firmware/hal/fm1_clk320.h`, `LICENSES/MIT-fm1-clk320.txt` |

## Third-party material

| What | Licence | Where |
| --- | --- | --- |
| IBM Plex Mono (SemiBold) by IBM Corp. and Michroma by The Michroma Project Authors: the UI's values and big titles since JIANT 0.6.56, rasterised into the firmware at build time (`tools/gen_aa_font.py --preset jiant-lab`; the generated tables are not offered as a font) | SIL OFL 1.1 | `assets/fonts/IBMPlexMono-SemiBold.ttf`, `assets/fonts/Michroma-Regular.ttf`, `LICENSES/OFL-IBMPlexMono.txt`, `LICENSES/OFL-Michroma.txt` |
| Chakra Petch font by The Chakra Petch Project Authors: the UI text since JIANT 0.5 (the labels since 0.6.56), rasterised into the firmware at build time (`tools/gen_aa_font.py --preset chakra-petch`; the generated tables are not offered as a font) | SIL OFL 1.1 | `assets/fonts/ChakraPetch-*.ttf`, `LICENSES/OFL-ChakraPetch.txt` (also `assets/fonts/OFL-ChakraPetch.txt`) |
| Inter Tight font by The Inter Project Authors: the UI text up to JIANT 0.4 (kept for the `inter-tight` preset; the font declares no Reserved Font Name) | SIL OFL 1.1 | `assets/fonts/InterTight[wght].ttf`, `LICENSES/OFL-InterTight.txt` (also `assets/fonts/OFL.txt`) |
| msfa by Google Inc. and Pascal Gauthier, from Dexed (<https://github.com/asb2m10/dexed>): the FM6 engine's synthesis, ported to integer C (Dexed itself is GPL-3.0; only msfa is used; the FM6 factory patches are Felucca's own) | Apache-2.0 | `firmware/src/fm6_core.c`, `LICENSES/Apache-2.0-msfa.txt` |
| klattsch by Tony Gies (<https://github.com/tgies/klattsch>): design reference for the VOICE engine; no code copied. Formant data from Klatt (1980) / Hillenbrand et al. (1995) | MIT (klattsch) | credit only |
| The CMU Pronouncing Dictionary (cmudict 0.7b, <https://github.com/cmusphinx/cmudict>) by Carnegie Mellon University: VOICE's English words (JIANT 0.8.5), a subset of ~2100 common words with their pronunciations, packed into the firmware at build time (`tools/gen_lyrics.py`) | BSD-2-Clause | `tools/lyrics/en_dict.txt` (the notice in its header), `LICENSES/BSD-2-Clause-CMUdict.txt` |
| X0X by charlesvestal (<https://github.com/charlesvestal/fm1-x0x>), a Felucca fork: the design of the browser emulator (the worklet, the device clock driven by its audio, the exports); its files credit it in their headers | GPL-3.0 | `web/emu/` |
| DotGothic16 font by The DotGothic16 Project Authors (<https://github.com/fontworks-fonts/DotGothic16>): the browser emulator's knob labels, served with its page (cut to printable ASCII; the font declares no Reserved Font Name) | SIL OFL 1.1 | `web/emu/fonts/DotGothic16-subset.woff`, `LICENSES/OFL-DotGothic16.txt` (also `web/emu/fonts/OFL.txt`) |
| JieLi AC79 SDK by JieLi Technology: three of its files go into every `.fwsc` package (below); none are in this tree | Apache-2.0 | `LICENSES/Apache-2.0.txt` |
| Skiff by illuminus5 (<https://github.com/illuminus5/skiff>), a Felucca fork: the designs of JIANT 0.9.12's 12 voices with the second core and the factory presets' sound types (written anew; no code copied) | GPL-3.0-only | credit only (`firmware/src/voice.c`, `firmware/src/core.h`) |
| MIDI LEARN from Felucca 1.5 by Leo Kuroshita (Hügelton Instruments), ported and modified for JIANT 0.9.12 | GPL-3.0-only | `firmware/src/midi_learn.c`, `firmware/src/midi_control.c` |

On the device, HOME held > ABOUT opens the information screen; turning PRESETS scrolls on into
CREDITS, a short list of these authors, licences and source URLs.

## JieLi SDK files in the packages (Apache-2.0)

A `.fwsc` package made by `tools/build.py` (with `tools/fm1pkg_make.py`; this is the package the
web installer installs) holds three unmodified files from the JieLi AC79 SDK
(<https://gitee.com/Jieli-Tech/fw-AC79_AIoT_SDK>, `cpu/wl82/tools/`). They are read from your SDK
checkout at build time (see BUILDING.md); no SDK files are in this tree.

| File in the package | What it is |
| --- | --- |
| `uboot.boot` | the first-stage boot loader (SPL) |
| `cfg_tool.bin` | the chip configuration block |
| `eq_cfg_hw.bin` | the default hardware EQ table |

They are licensed under the Apache License, Version 2.0 (`LICENSES/Apache-2.0.txt`), not under
the GPL, and their copyright stays with JieLi Technology. The SDK has no NOTICE file. Apache-2.0
files may be distributed together with GPL-3.0 code; Felucca itself stays GPL-3.0-only.

Every distribution of a package carries the licence texts with it: the release folder
(`tools/build.py --release`) and the site (`web/make_site.py`, next to the package in
`firmware/` and linked from the installer page).

## No vendor material

No M-VAVE material is part of Felucca. The firmware links no vendor code and contains no vendor
data, and the packages hold only Felucca and the three SDK files above. The installer's
"Return to official V15" holds only the official file's size and SHA-256: you select the
official firmware file you downloaded yourself, and it is checked and installed in your browser,
never uploaded or redistributed.

## Contributions

Contributions are welcome under GPL-3.0-only.

## Trademarks

"Felucca" and "Hügelton Instruments" are names of Hügelton Instruments.

"M-VAVE" and "FM-1" are trademarks of their respective owners. Felucca is independent
firmware that runs on FM-1 hardware. It is not affiliated with, endorsed by or supported
by those owners.

## Radio

Felucca never enables the Bluetooth / Wi-Fi radio of the hardware.

## Rhythmer 0.1.1 additions

Hortator ACID and the additional MD factory colours are adapted from DeadActive/hortator, commit `44c9ad4aa57bebf63f412bd552e57143c30b4065`, under GPL-3.0-only. Their original copyright notices remain in the source; the adapters and reproduction scripts are included. The 21 MD synthesis models expose all 55 upstream MD factory sounds, deduplicated into 57 parameter articulations (including the shaker and clave base defaults). These are adaptations to Rhythmer's compact controls, rather than bit-identical Hortator preset serialization.

GEN includes nine curated progressions selected from Jazzy Rhythmer's JR TREK library: six original JR entries and three SHLD entries from ldrolez/free-midi-chords (MIT, source revision `95533fae2c1a2aae032211b9abed0441ac8ba298`). See `LICENSES/MIT-SHLD.txt` and `firmware/data/genres/jr-chords.json` for exact selected rows and source attribution. Four-voice reductions retain identifying extensions while the bass supplies the root. JR PLAY's role-aware velocity/timing design is adapted to deterministic, offline groove cells. No neural network, remote service, JavaScript music engine, MIDI recording, or commercial chord library runs in the firmware.
