# SPDX-License-Identifier: GPL-3.0-only
# Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments
"""Minimal LZ4 *block* format (no frame), written for the Felucca loader
wrapper: greedy hash-chain-free compressor and a decoder for self-checks.
Spec: https://github.com/lz4/lz4/blob/dev/doc/lz4_Block_format.md
(min match 4, last 5 bytes literals, last match starts >= 12 bytes before the end)."""


def _len_bytes(n):
    out = bytearray()
    while n >= 255:
        out.append(255)
        n -= 255
    out.append(n)
    return out


def compress(src: bytes) -> bytes:
    n, out, table = len(src), bytearray(), {}
    anchor, i = 0, 0
    limit = n - 12                                  # matches must start before this
    while i < limit:
        key = src[i:i + 4]
        cand = table.get(key)
        table[key] = i
        if cand is None or i - cand > 65535:
            i += 1
            continue
        mlen = 4                                    # extend; leave the last 5 bytes as literals
        while i + mlen < n - 5 and src[cand + mlen] == src[i + mlen]:
            mlen += 1
        lit = src[anchor:i]
        tok = (min(len(lit), 15) << 4) | min(mlen - 4, 15)
        out.append(tok)
        if len(lit) >= 15:
            out += _len_bytes(len(lit) - 15)
        out += lit
        off = i - cand
        out += bytes((off & 0xFF, off >> 8))
        if mlen - 4 >= 15:
            out += _len_bytes(mlen - 4 - 15)
        i += mlen
        anchor = i
    lit = src[anchor:]                              # final literal run
    out.append(min(len(lit), 15) << 4)
    if len(lit) >= 15:
        out += _len_bytes(len(lit) - 15)
    out += lit
    return bytes(out)


def compress_small(src: bytes) -> bytes:
    """Choose the smallest encoding of a short block, offline only."""
    n = len(src)
    longest, candidates = {}, {}
    for i in range(max(0, n - 11)):
        chain = candidates.setdefault(src[i:i + 4], [])
        off, size = 0, 3
        for prev in reversed(chain):
            if i - prev > 65535:
                break
            m = 4
            while i + m < n - 5 and src[prev + m] == src[i + m]:
                m += 1
            if m > size:
                off, size = i - prev, m
                if i + m == n - 5:
                    break
        if off:
            longest[i] = off, size
        chain.append(i)

    def extended(length, limit):
        return 1 + (length - limit) // 255 if length >= limit else 0

    costs = [0] * (n + 1)
    choice = [None] * (n + 1)
    matches = []
    for i in range(n, -1, -1):
        if i in longest:
            off, size = longest[i]
            m = min(range(4, size + 1), key=lambda k: costs[i + k] + extended(k, 19))
            matches.append((i, off, m, 3 + extended(m, 19) + costs[i + m]))
        costs[i] = 1 + n - i + extended(n - i, 15)
        for at, off, m, cost in matches:
            ll = at - i
            cost += ll + extended(ll, 15)
            if cost < costs[i]:
                costs[i], choice[i] = cost, (at, off, m)

    out, i = bytearray(), 0
    while True:
        match = choice[i]
        at, off, m = match if match else (n, 0, 4)
        ll = at - i
        out.append((min(ll, 15) << 4) | min(m - 4, 15))
        if ll >= 15:
            out += _len_bytes(ll - 15)
        out += src[i:at]
        if not match:
            break
        out += bytes((off & 255, off >> 8))
        if m >= 19:
            out += _len_bytes(m - 19)
        i = at + m
    assert len(out) == costs[0]
    return bytes(out)


def decompress(blk: bytes, prefix: bytes = b"") -> bytes:
    out, i = bytearray(prefix), 0
    while i < len(blk):
        tok = blk[i]
        i += 1
        ll = tok >> 4
        if ll == 15:
            while True:
                b = blk[i]
                i += 1
                ll += b
                if b != 255:
                    break
        out += blk[i:i + ll]
        i += ll
        if i >= len(blk):
            break
        off = blk[i] | blk[i + 1] << 8
        i += 2
        ml = tok & 15
        if ml == 15:
            while True:
                b = blk[i]
                i += 1
                ml += b
                if b != 255:
                    break
        ml += 4
        for _ in range(ml):
            out.append(out[-off])
    return bytes(out[len(prefix):])
