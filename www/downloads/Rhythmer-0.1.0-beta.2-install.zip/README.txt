RHYTHMER / PUBLIC BETA INSTALLATION

Open the installer linked in the repository README in Chrome or Edge. Press
INSTALL RHYTHMER. The page loads this exact installation bundle automatically,
identifies one FM-1, prepares a backup where supported, and requests a final
review. The integrated firmware image includes both Break banks. One firmware
transfer writes the app and fixed audio banks; no separate sample upload runs.
The installer verifies device identity and the firmware's bank-validity flags.

Rhythmer.fwsc includes the app, integrated loader and both factory Break banks.
The .rhythmer file additionally wraps recovery and provenance; it is not a format the stock updater can
flash directly. Do not feed it to M-UPGRADE. Official V15 recovery is separate
and unmodified; its Apache-2.0 license, source and notices are included.

Read the release-specific test record. This release fixes SEQ note visibility.
Host and emulator checks passed; this exact binary is not physically tested.
Earlier owner hardware tests apply to beta.1, not automatically to this package.
Musical archives exclude Break audio; retain original audio files separately.
This bundle contains original Amen/Think recordings. The owner directs their
distribution with credits; rights-holder redistribution permission has not
been documented. This is not a blanket license for users.
Read THIRD-PARTY-AUDIO.txt and audio-rights.json. Credits are not a license.
