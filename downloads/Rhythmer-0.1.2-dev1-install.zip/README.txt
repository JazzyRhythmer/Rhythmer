# Restored playback base · 20261112.1

This release restores the single-Break playback implementation from the preserved JAZZY 20261111.2 and RHYTHMER 20261110.3 sources. Their unmodified rebuilds differ from the original application binaries only in the displayed compile date; all other program bytes match. Track-state allocation, audio buffers, scheduling and the earlier generator behavior are restored rather than reimplemented.

Only these firmware fixes are applied: HYDRA enables its high-note oversampling when a legato/glide phrase crosses the pitch threshold; LXR uses the track ADSR together with its native drum decay, with filter and FX processing retained; missing factory FX sends default to zero, while explicit preset FX and saved project/user-sound settings remain. Acid and Break load with all four sends at zero. There is no Acid-specific send branch.

Break is limited to one track. GEN uses the earlier track targets and dedicated BREAK target again. Keep projects from newer versions backed up; projects containing several Break tracks must be reduced to one Break before use with this version.

Both bundled Break banks are unchanged: A / Amen and B / Think. Installation replaces A/B, so keep your original custom audio and converted .slot files. RHYTHMER and JAZZY direct updates remain supported; V15 is not required between the two companion firmwares. Save the automatic musical backup before installation.

Software checks cover both constrained firmware builds, all available factory presets, dry defaults and saved mix preservation, all 14 HYDRA presets crossing the high-note threshold, and release termination across all 595 LXR presets. Physical FM-1 installation and endurance validation are separate. The reported broad playback regression has not been declared fixed by software tests alone; this rollback restores the earlier playback base for device verification.

RHYTHMER / PUBLIC BETA INSTALLATION

Open the installer linked in the repository README in Chrome or Edge. Press
INSTALL RHYTHMER. The page loads this exact installation bundle automatically,
identifies one FM-1, prepares a backup where supported, and requests a final
review. The integrated firmware image includes both Break banks. One firmware
transfer writes the app and fixed audio banks; no separate sample upload runs.
The installer verifies device identity and the firmware's bank-validity flags.

Rhythmer.fwsc includes the app, integrated loader and both factory Break banks.
The .rhythmer file additionally wraps recovery and provenance; it is not a format the stock updater can
flash directly. Do not feed it to M-UPGRADE. Official V15 recovery is separate
and unmodified; its Apache-2.0 license, source and notices are included.

Read the release-specific test record and change log. Host and emulator
checks passed; this exact binary is not physically tested. Earlier owner
hardware results do not automatically apply to this package.
Musical archives exclude Break audio; retain original audio files separately.
This bundle contains original Amen/Think recordings. The owner directs their
distribution with credits; rights-holder redistribution permission has not
been documented. This is not a blanket license for users.
Read THIRD-PARTY-AUDIO.txt and audio-rights.json. Credits are not a license.
