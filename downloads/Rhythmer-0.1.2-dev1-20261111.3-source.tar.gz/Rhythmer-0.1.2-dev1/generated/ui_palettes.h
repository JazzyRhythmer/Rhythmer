/* generated: four Rhythmer palettes, stable archive ids */
#pragma once
static const ui_pal_t UI_PALETTES[] = {
    {"MONO",0x0000,0x0000,0xffff,0xffff,0xffff},
    {"INVERT",0xffff,0xffff,0x0000,0x0000,0x0000},
    {"RED",0x0000,0x0000,0xfa8a,0xfa8a,0xfa8a},
    {"RED INV",0xfa8a,0xfa8a,0x0000,0x0000,0x0000},
};
static const uint8_t UI_STORAGE_IDS[4]={73,75,76,77};
static const uint8_t UI_RAISE_OF[4]={12,12,12,12};
static const uint16_t UI_KNOBS[4][4]={ {0xffff,0xffff,0xffff,0xffff},{0,0,0,0},{0xfa8a,0xfa8a,0xfa8a,0xfa8a},{0,0,0,0} };
#define UI_NPALETTES 4u
#define UI_BW_INDEX 0u
#define UI_INVERT_INDEX 1u
#define UI_BW_GREY 0x528au
#define UI_PAL_TAG 64u
#define UI_MID_PCT 70
#define UI_DIM_PCT 42
#define UI_LINE_PCT 18
#define UI_SEL_PCT 80
#define UI_TINT_PCT 12
#define UI_KEY_PCT 78
#define UI_RAISE_PCT 12
#define UI_REC_DARK 0xffffu
#define UI_REC_LIGHT 0u
#define UI_QR_LIGHT 0xffffu
#define UI_QR_DARK 0u
#define UI_CRASH_BG 0u
#define UI_CRASH_INK 0xffffu
